"""neuroformal/__init__.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from .models import FaithfulnessProofArtifact, FormalProofArtifact, NeuroFormalExecutionResult, TranslationCertificate
from .registry import NeuroFormalProofRegistry
from .runtime import NeuroFormalRuntime, compute_hash

__all__ = [
    "FaithfulnessProofArtifact",
    "FormalProofArtifact",
    "NeuroFormalExecutionResult",
    "TranslationCertificate",
    "NeuroFormalProofRegistry",
    "NeuroFormalRuntime",
    "compute_hash",
]
