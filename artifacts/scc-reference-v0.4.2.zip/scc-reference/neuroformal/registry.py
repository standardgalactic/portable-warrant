"""neuroformal/registry.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from typing import Callable, Dict, Optional

from .models import FaithfulnessProofArtifact, FormalProofArtifact

SourceDomainPredicate = Callable[[str], bool]


class NeuroFormalProofRegistry:
    """Trusted store for terminal proofs, bridge proofs, domains, and translator identities."""

    def __init__(self) -> None:
        """Initialize this in-memory runtime or registry object.

        Initialization performs no external I/O.  Supplied dependencies are retained for subsequent deterministic evaluation.
        """
        self._formal_proofs: Dict[str, FormalProofArtifact] = {}
        self._faithfulness_proofs: Dict[str, FaithfulnessProofArtifact] = {}
        self._domains: Dict[str, SourceDomainPredicate] = {}
        self._translator_versions: Dict[str, str] = {}
        self._translator_configs: Dict[str, str] = {}

    def trust_translator(self, translator_id: str, version_hash: str, configuration_hash: str) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._translator_versions[translator_id] = version_hash
        self._translator_configs[translator_id] = configuration_hash

    def translator_authenticates(self, translator_id: str, version_hash: str, configuration_hash: str) -> bool:
        """Authenticate exact evidence bindings against the trusted registry.

        Returns bool.  False means the required binding cannot be established; it is not a proof that the underlying action is unsafe.
        """
        return (
            self._translator_versions.get(translator_id) == version_hash
            and self._translator_configs.get(translator_id) == configuration_hash
        )

    def register_domain(self, domain_hash: str, predicate: SourceDomainPredicate) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._domains[domain_hash] = predicate

    def domain_predicate(self, domain_hash: str) -> Optional[SourceDomainPredicate]:
        """Resolve a trusted registry object by its identifier.

        Returns the registered object when present and None when the identifier is unknown.  No fallback inference is performed.
        """
        return self._domains.get(domain_hash)

    def register_formal_proof(self, artifact: FormalProofArtifact) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._formal_proofs[artifact.proof_id] = artifact

    def formal_proof(self, proof_id: str) -> Optional[FormalProofArtifact]:
        """Resolve a trusted registry object by its identifier.

        Returns the registered object when present and None when the identifier is unknown.  No fallback inference is performed.
        """
        return self._formal_proofs.get(proof_id)

    def register_faithfulness_proof(self, artifact: FaithfulnessProofArtifact) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._faithfulness_proofs[artifact.faithfulness_hash] = artifact

    def faithfulness_proof(self, proof_hash: str) -> Optional[FaithfulnessProofArtifact]:
        """Resolve a trusted registry object by its identifier.

        Returns the registered object when present and None when the identifier is unknown.  No fallback inference is performed.
        """
        return self._faithfulness_proofs.get(proof_hash)
