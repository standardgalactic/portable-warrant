"""neuroformal/models.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class TranslationCertificate(BaseModel):
    model_config = ConfigDict(frozen=True)

    certificate_id: str
    source_artifact_hash: str = Field(description="h(x): hash of source program/spec")
    translated_artifact_hash: str = Field(description="h(y): hash of formal target representation")
    translator_id: str
    translator_version_hash: str
    translation_configuration_hash: str
    source_property_hash: str
    target_property_hash: str
    admitted_domain_hash: str
    faithfulness_proof_hash: str
    direction: Literal["EQUIVALENCE", "TARGET_IMPLIES_SOURCE", "SOURCE_IMPLIES_TARGET"] = "TARGET_IMPLIES_SOURCE"
    parent_certificate_ids: List[str] = Field(default_factory=list)


class FormalProofArtifact(BaseModel):
    model_config = ConfigDict(frozen=True)

    proof_id: str
    translated_artifact_hash: str
    target_property_hash: str
    verifier_id: str
    verifier_version: str
    terminal_proof_verified: bool


class FaithfulnessProofArtifact(BaseModel):
    model_config = ConfigDict(frozen=True)

    faithfulness_hash: str
    translator_id: str
    translator_version_hash: str
    translation_configuration_hash: str
    source_property_hash: str
    target_property_hash: str
    admitted_domain_hash: str
    direction: Literal["EQUIVALENCE", "TARGET_IMPLIES_SOURCE", "SOURCE_IMPLIES_TARGET"]
    bridge_theorem_verified: bool


NeuroFormalReasonCode = Literal[
    "SOURCE_HASH_MISMATCH",
    "TARGET_HASH_MISMATCH",
    "PROPERTY_BINDING_MISMATCH",
    "TRANSLATOR_VERSION_HASH_MISMATCH",
    "TRANSLATION_CONFIGURATION_HASH_MISMATCH",
    "UNKNOWN_TRANSLATION_DOMAIN",
    "TRANSLATION_DOMAIN_MISMATCH",
    "UNVERIFIED_TRANSLATION_FAITHFULNESS",
    "INVALID_BRIDGE_DIRECTION",
    "UNVERIFIED_TERMINAL_PROOF",
]


class NeuroFormalExecutionResult(BaseModel):
    status: Literal["PROCEED", "NULL_ACTION", "ABORT"]
    reason_code: Optional[NeuroFormalReasonCode] = None
    source_warrant_derived: bool = False
