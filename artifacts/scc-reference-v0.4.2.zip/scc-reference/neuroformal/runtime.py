"""neuroformal/runtime.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

import hashlib

from .models import NeuroFormalExecutionResult, TranslationCertificate
from .registry import NeuroFormalProofRegistry


def compute_hash(content: str) -> str:
    """Implement the `compute_hash` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()


class NeuroFormalRuntime:
    """Derives a source-level warrant only from a closed, authenticated evidence chain."""

    def __init__(self, registry: NeuroFormalProofRegistry) -> None:
        """Initialize this in-memory runtime or registry object.

        Initialization performs no external I/O.  Supplied dependencies are retained for subsequent deterministic evaluation.
        """
        self.registry = registry

    def evaluate(
        self,
        *,
        source_content: str,
        translated_content: str,
        translation_cert: TranslationCertificate,
        formal_proof_id: str,
    ) -> NeuroFormalExecutionResult:
        """Implement the `evaluate` operation documented in the API and manual pages.

        See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
        """
        if compute_hash(source_content) != translation_cert.source_artifact_hash:
            return self._abort("SOURCE_HASH_MISMATCH")

        if compute_hash(translated_content) != translation_cert.translated_artifact_hash:
            return self._abort("TARGET_HASH_MISMATCH")

        if translation_cert.direction not in ("EQUIVALENCE", "TARGET_IMPLIES_SOURCE"):
            return self._null("INVALID_BRIDGE_DIRECTION")

        if not self.registry.translator_authenticates(
            translation_cert.translator_id,
            translation_cert.translator_version_hash,
            translation_cert.translation_configuration_hash,
        ):
            return self._abort("TRANSLATOR_VERSION_HASH_MISMATCH")

        bridge = self.registry.faithfulness_proof(translation_cert.faithfulness_proof_hash)
        if bridge is None or not bridge.bridge_theorem_verified:
            return self._null("UNVERIFIED_TRANSLATION_FAITHFULNESS")

        if bridge.translator_id != translation_cert.translator_id or bridge.translator_version_hash != translation_cert.translator_version_hash:
            return self._abort("TRANSLATOR_VERSION_HASH_MISMATCH")

        if bridge.translation_configuration_hash != translation_cert.translation_configuration_hash:
            return self._abort("TRANSLATION_CONFIGURATION_HASH_MISMATCH")

        if (
            bridge.source_property_hash != translation_cert.source_property_hash
            or bridge.target_property_hash != translation_cert.target_property_hash
            or bridge.admitted_domain_hash != translation_cert.admitted_domain_hash
        ):
            return self._abort("PROPERTY_BINDING_MISMATCH")

        if bridge.direction not in ("EQUIVALENCE", "TARGET_IMPLIES_SOURCE"):
            return self._null("INVALID_BRIDGE_DIRECTION")

        domain = self.registry.domain_predicate(translation_cert.admitted_domain_hash)
        if domain is None:
            return self._abort("UNKNOWN_TRANSLATION_DOMAIN")
        if not domain(source_content):
            return self._null("TRANSLATION_DOMAIN_MISMATCH")

        terminal = self.registry.formal_proof(formal_proof_id)
        if terminal is None or not terminal.terminal_proof_verified:
            return self._null("UNVERIFIED_TERMINAL_PROOF")

        if terminal.translated_artifact_hash != translation_cert.translated_artifact_hash:
            return self._abort("TARGET_HASH_MISMATCH")
        if terminal.target_property_hash != translation_cert.target_property_hash:
            return self._abort("PROPERTY_BINDING_MISMATCH")

        return NeuroFormalExecutionResult(status="PROCEED", source_warrant_derived=True)

    @staticmethod
    def _null(reason: str) -> NeuroFormalExecutionResult:
        """Internal helper used to normalize runtime behavior.

        This private interface is not a standalone authorization boundary and should not be treated as one by callers.
        """
        return NeuroFormalExecutionResult(status="NULL_ACTION", reason_code=reason, source_warrant_derived=False)

    @staticmethod
    def _abort(reason: str) -> NeuroFormalExecutionResult:
        """Internal helper used to normalize runtime behavior.

        This private interface is not a standalone authorization boundary and should not be treated as one by callers.
        """
        return NeuroFormalExecutionResult(status="ABORT", reason_code=reason, source_warrant_derived=False)
