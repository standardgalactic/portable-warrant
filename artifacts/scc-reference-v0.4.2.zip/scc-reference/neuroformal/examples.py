"""neuroformal/examples.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from .models import FaithfulnessProofArtifact, FormalProofArtifact, TranslationCertificate
from .registry import NeuroFormalProofRegistry
from .runtime import NeuroFormalRuntime, compute_hash

AUTHORIZED_SOURCE = "resource=ledger\nauthorization=allow\ndestination=external\n"
UNAUTHORIZED_SOURCE = "resource=ledger\nauthorization=deny\ndestination=external\n"
FORMAL_STUB = "(assert target_property_holds)"


def defective_translate(_: str) -> str:
    """Deliberately erases the authorization modifier, collapsing two source fibers."""
    return FORMAL_STUB


def build_example() -> tuple[NeuroFormalRuntime, TranslationCertificate, FormalProofArtifact]:
    """Implement the `build_example` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    registry = NeuroFormalProofRegistry()
    translator_id = "translator:defective-demo"
    translator_version = "sha256:translator-v1"
    translator_config = "sha256:strip-auth-demo"
    domain_hash = "sha256:domain-authorized-only"
    source_property = "sha256:property-source-authorized"
    target_property = "sha256:property-target-stub-safe"

    registry.trust_translator(translator_id, translator_version, translator_config)
    registry.register_domain(domain_hash, lambda source: "authorization=allow" in source)

    bridge = FaithfulnessProofArtifact(
        faithfulness_hash="sha256:bridge-authorized-domain",
        translator_id=translator_id,
        translator_version_hash=translator_version,
        translation_configuration_hash=translator_config,
        source_property_hash=source_property,
        target_property_hash=target_property,
        admitted_domain_hash=domain_hash,
        direction="TARGET_IMPLIES_SOURCE",
        bridge_theorem_verified=True,
    )
    registry.register_faithfulness_proof(bridge)

    target = defective_translate(AUTHORIZED_SOURCE)
    terminal = FormalProofArtifact(
        proof_id="proof:terminal-stub",
        translated_artifact_hash=compute_hash(target),
        target_property_hash=target_property,
        verifier_id="demo-verifier",
        verifier_version="1",
        terminal_proof_verified=True,
    )
    registry.register_formal_proof(terminal)

    cert = TranslationCertificate(
        certificate_id="translation:authorized-source",
        source_artifact_hash=compute_hash(AUTHORIZED_SOURCE),
        translated_artifact_hash=compute_hash(target),
        translator_id=translator_id,
        translator_version_hash=translator_version,
        translation_configuration_hash=translator_config,
        source_property_hash=source_property,
        target_property_hash=target_property,
        admitted_domain_hash=domain_hash,
        faithfulness_proof_hash=bridge.faithfulness_hash,
        direction="TARGET_IMPLIES_SOURCE",
    )
    return NeuroFormalRuntime(registry), cert, terminal
