# SCC-BASIC-32 / FreeBASIC notes

FreeBASIC is suitable for a fuller native port. Preserve the portable kernel API, use exact-width integer types for cryptographic code, keep canonical serialization byte-defined, and validate the shared vectors before adding host-specific execution adapters.
