# SCC-BASIC-16 / QBasic notes

Treat strings and fixed records as transport only. Do not implement SHA-256 with floating-point arithmetic. If no trustworthy integer/crypto primitive is resident, invoke an independently authenticated verifier or derive no warrant. File replacement should use write-new, close, verify, then rename where the host permits it. Chain depth is explicitly bounded.
