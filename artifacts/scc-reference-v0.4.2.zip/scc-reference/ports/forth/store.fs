\ store.fs -- evidence-store contract
\ A host profile MUST resolve proof identifiers to authenticated evidence.
\ Failure to resolve is UNVERIFIED-PROOF, never TRUE by default.
: unresolved-proof ( -- flag reason ) false UNVERIFIED-PROOF ;
