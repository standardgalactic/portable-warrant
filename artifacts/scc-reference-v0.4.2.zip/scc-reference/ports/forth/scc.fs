\ scc.fs -- SCC Portable Kernel, ANS-style Forth
0  CONSTANT SCC-OK
76 CONSTANT UNVERIFIED-PROOF
77 CONSTANT DOMAIN-MISMATCH
78 CONSTANT COMPOSITION-REQUIRED

\ Inputs are flags: proof domain composition-required composition-ok
\ Result: warranted? reason
: warrant? ( proof domain need-comp comp -- flag reason )
  >r >r                         \ proof domain ; R: comp need-comp
  swap 0= IF drop rdrop rdrop false UNVERIFIED-PROOF EXIT THEN
  0= IF rdrop rdrop false DOMAIN-MISMATCH EXIT THEN
  r> r>                         \ comp need-comp
  swap                          \ need-comp comp
  over IF 0= IF drop false COMPOSITION-REQUIRED EXIT THEN ELSE drop THEN
  drop true SCC-OK ;

: .decision ( flag reason -- )
  swap IF drop ." PROCEED" cr EXIT THEN
  ." NULL ACTION "
  dup UNVERIFIED-PROOF = IF drop ." UNVERIFIED_PROOF_OBLIGATION" cr EXIT THEN
  dup DOMAIN-MISMATCH = IF drop ." DOMAIN_MISMATCH" cr EXIT THEN
  dup COMPOSITION-REQUIRED = IF drop ." COMPOSITION_PROOF_REQUIRED" cr EXIT THEN
  . cr ;
