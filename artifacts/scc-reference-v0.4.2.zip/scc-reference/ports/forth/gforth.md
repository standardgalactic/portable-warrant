# SCC-FORTH-GFORTH

Gforth can host the portable kernel while adapters provide files, subprocesses, and cryptographic verification. Keep those words outside `scc.fs`. Test the pure kernel first, then test adapter-produced flags against the same evidence vectors used by the Python reference runtime.
