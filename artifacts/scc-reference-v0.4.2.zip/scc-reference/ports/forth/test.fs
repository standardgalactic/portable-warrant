include scc.fs
variable failures
: assert2 ( flag reason expflag expreason -- )
  >r >r swap r> = swap r> = and 0= IF 1 failures +! THEN ;
true true false false warrant? true SCC-OK assert2
false true false false warrant? false UNVERIFIED-PROOF assert2
true false false false warrant? false DOMAIN-MISMATCH assert2
true true true false warrant? false COMPOSITION-REQUIRED assert2
true true true true warrant? true SCC-OK assert2
failures @ 0= IF ." SCC FORTH PORT: 5 TESTS PASS" cr ELSE ." SCC FORTH PORT: FAIL" cr THEN
bye
