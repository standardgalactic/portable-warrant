\ cert.fs -- minimal certificate record fields; storage is host-profile specific.
0 constant CERT-ID
1 constant PROPERTY-ID
2 constant PROJECTION-ID
3 constant DOMAIN-ID
4 constant PROOF-ID
5 constant DEPTH
6 constant /CERT
