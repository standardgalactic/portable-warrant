include scc.fs
true true false false warrant? .decision
true true true false warrant? .decision
