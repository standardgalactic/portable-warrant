# SCC-FORTH-ANS

Keep the kernel dependent only on ordinary stack, control-flow, and integer operations. File I/O, SHA-256, signatures, clocks, and process execution belong to host profiles. The portable word `warrant?` therefore consumes already-authenticated gate results; the host adapter is responsible for producing those results from evidence objects.
