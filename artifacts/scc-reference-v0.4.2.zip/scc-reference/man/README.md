# Manual pages

The `man/` tree follows Unix section conventions: section 1 for commands, section 3 for Python/library interfaces, section 5 for certificate/evidence formats, and section 7 for the warrant-preservation calculus.

Read without installing, for example:

```sh
man -l man/man7/scc-warrant-calculus.7
man -l man/man3/scc_runtime.3
man -l man/man3/sccruntimeengine_evaluate_warrant.3
```

`docs/api.md` is the corresponding browsable API manual.
