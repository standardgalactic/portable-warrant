"""scc_runtime/legacy.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from .models import ExecutionResult, History


def legacy_boolean_runtime(current_state: History) -> ExecutionResult:
    """Illustrates the unsafe assumption that local PASS is transitively sufficient."""
    violated = current_state.origin == "restricted" and current_state.destination == "external"
    return ExecutionResult(
        status="PROCEED",
        reason_code=None,
        sink_invoked=True,
        global_invariant_violated=violated,
    )
