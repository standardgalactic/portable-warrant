"""scc_runtime/__init__.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from .engine import SCCRuntimeEngine
from .legacy import legacy_boolean_runtime
from .models import (
    CompositionScope,
    ExecutionResult,
    History,
    ScopeCarryingCertificate,
    VerifiedCompositionArtifact,
    VerifiedProofArtifact,
)
from .registry import TrustedProofRegistry

__all__ = [
    "SCCRuntimeEngine",
    "legacy_boolean_runtime",
    "CompositionScope",
    "ExecutionResult",
    "History",
    "ScopeCarryingCertificate",
    "VerifiedCompositionArtifact",
    "VerifiedProofArtifact",
    "TrustedProofRegistry",
]
