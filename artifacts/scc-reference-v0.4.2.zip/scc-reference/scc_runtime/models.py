"""scc_runtime/models.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator


class History(BaseModel):
    origin: Literal["public", "restricted"]
    destination: Literal["internal", "external"]


class CompositionScope(BaseModel):
    permitted_consumers: List[str]
    max_delegation_depth: int = Field(ge=0)
    current_depth: int = Field(default=0, ge=0)
    parent_certificate_id: Optional[str] = None
    allow_delegation: bool = True
    allow_independent_joins: bool = False


class ScopeCarryingCertificate(BaseModel):
    model_config = ConfigDict(frozen=True)

    certificate_id: str
    property_hash: str
    projection_hash: str
    proof_hash: str
    admitted_domain_hash: str
    verifier_version: str
    environmental_assumptions: List[str]
    validity_interval: tuple[datetime, datetime]
    composition_scope: CompositionScope
    disposition: Literal["PROCEED", "DEFER", "ABORT"]
    boundary_observations: Dict[str, Any]

    @model_validator(mode="after")
    def valid_interval(self) -> "ScopeCarryingCertificate":
        """Implement the `valid_interval` operation documented in the API and manual pages.

        See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
        """
        start, end = self.validity_interval
        if start > end:
            raise ValueError("validity_interval start must not exceed end")
        return self


class VerifiedProofArtifact(BaseModel):
    model_config = ConfigDict(frozen=True)

    proof_hash: str
    property_hash: str
    projection_hash: str
    domain_hash: str
    verifier_version: str
    factorization_verified: bool


class VerifiedCompositionArtifact(BaseModel):
    model_config = ConfigDict(frozen=True)

    proof_hash: str
    parent_certificate_id: str
    consumer_agent_id: str
    transformation_hash: str
    property_hash: str
    domain_hash: str
    verifier_version: str
    composition_verified: bool


ReasonCode = Literal[
    "UNVERIFIED_PROOF_OBLIGATION",
    "UNKNOWN_DOMAIN_SPEC",
    "DOMAIN_MISMATCH",
    "STALE_CERTIFICATE",
    "ASSUMPTION_FAILURE",
    "UNAUTHORIZED_CONSUMER",
    "DELEGATION_NOT_ALLOWED",
    "DELEGATION_DEPTH_EXCEEDED",
    "COMPOSITION_PROOF_REQUIRED",
    "INVALID_COMPOSITION_PROOF",
    "JOIN_PROOF_REQUIRED",
]


class ExecutionResult(BaseModel):
    status: Literal["PROCEED", "NULL_ACTION", "ABORT"]
    reason_code: Optional[ReasonCode] = None
    sink_invoked: bool
    global_invariant_violated: bool
