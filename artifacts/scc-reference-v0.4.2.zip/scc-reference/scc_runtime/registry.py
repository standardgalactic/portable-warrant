"""scc_runtime/registry.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from typing import Callable, Dict, Optional

from .models import (
    History,
    ScopeCarryingCertificate,
    VerifiedCompositionArtifact,
    VerifiedProofArtifact,
)

DomainPredicate = Callable[[History], bool]


class TrustedProofRegistry:
    """Trusted store for proof artifacts and immutable domain semantics."""

    def __init__(self) -> None:
        """Initialize this in-memory runtime or registry object.

        Initialization performs no external I/O.  Supplied dependencies are retained for subsequent deterministic evaluation.
        """
        self._proofs: Dict[str, VerifiedProofArtifact] = {}
        self._compositions: Dict[str, VerifiedCompositionArtifact] = {}
        self._domains: Dict[str, DomainPredicate] = {}

    def register_domain(self, domain_hash: str, predicate: DomainPredicate) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._domains[domain_hash] = predicate

    def register_proof(self, artifact: VerifiedProofArtifact) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._proofs[artifact.proof_hash] = artifact

    def register_composition(self, artifact: VerifiedCompositionArtifact) -> None:
        """Register trusted evidence or semantics in the in-memory registry.

        Registration mutates only the registry instance.  Reusing an existing key replaces its previous binding in this reference implementation.
        """
        self._compositions[artifact.proof_hash] = artifact

    def proof_authenticates(self, cert: ScopeCarryingCertificate) -> bool:
        """Authenticate exact evidence bindings against the trusted registry.

        Returns bool.  False means the required binding cannot be established; it is not a proof that the underlying action is unsafe.
        """
        artifact = self._proofs.get(cert.proof_hash)
        if artifact is None:
            return False
        return (
            artifact.factorization_verified
            and artifact.property_hash == cert.property_hash
            and artifact.projection_hash == cert.projection_hash
            and artifact.domain_hash == cert.admitted_domain_hash
            and artifact.verifier_version == cert.verifier_version
        )

    def domain_predicate(self, domain_hash: str) -> Optional[DomainPredicate]:
        """Resolve a trusted registry object by its identifier.

        Returns the registered object when present and None when the identifier is unknown.  No fallback inference is performed.
        """
        return self._domains.get(domain_hash)

    def composition_authenticates(
        self,
        proof_hash: str,
        cert: ScopeCarryingCertificate,
        consumer_agent_id: str,
        transformation_hash: str,
    ) -> bool:
        """Authenticate exact evidence bindings against the trusted registry.

        Returns bool.  False means the required binding cannot be established; it is not a proof that the underlying action is unsafe.
        """
        artifact = self._compositions.get(proof_hash)
        if artifact is None:
            return False
        return (
            artifact.composition_verified
            and artifact.parent_certificate_id == cert.certificate_id
            and artifact.consumer_agent_id == consumer_agent_id
            and artifact.transformation_hash == transformation_hash
            and artifact.property_hash == cert.property_hash
            and artifact.domain_hash == cert.admitted_domain_hash
            and artifact.verifier_version == cert.verifier_version
        )
