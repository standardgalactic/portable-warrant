"""scc_runtime/engine.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, Optional

from .models import ExecutionResult, History, ScopeCarryingCertificate
from .registry import TrustedProofRegistry


class SCCRuntimeEngine:
    """Three-gate SCC enforcement engine.

    Authorization consumes evidence objects rather than caller-provided booleans.
    """

    def __init__(self, current_time: datetime, proof_registry: TrustedProofRegistry):
        """Initialize this in-memory runtime or registry object.

        Initialization performs no external I/O.  Supplied dependencies are retained for subsequent deterministic evaluation.
        """
        self.current_time = current_time
        self.registry = proof_registry

    @staticmethod
    def _result(status: str, reason: Optional[str] = None, *, sink: bool = False, violated: bool = False) -> ExecutionResult:
        """Internal helper used to normalize runtime behavior.

        This private interface is not a standalone authorization boundary and should not be treated as one by callers.
        """
        return ExecutionResult(
            status=status,
            reason_code=reason,
            sink_invoked=sink,
            global_invariant_violated=violated,
        )

    def evaluate_warrant(
        self,
        cert: ScopeCarryingCertificate,
        current_state: History,
        consumer_agent_id: str,
        *,
        composition_proof_hash: Optional[str] = None,
        transformation_hash: Optional[str] = None,
        environmental_state: Optional[Dict[str, bool]] = None,
    ) -> ExecutionResult:
        """Implement the `evaluate_warrant` operation documented in the API and manual pages.

        See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
        """
        environmental_state = environmental_state or {}

        # Gate 1: authenticate the static factorization proof.
        if not self.registry.proof_authenticates(cert):
            return self._result("ABORT", "UNVERIFIED_PROOF_OBLIGATION")

        start, end = cert.validity_interval
        if not (start <= self.current_time <= end):
            return self._result("ABORT", "STALE_CERTIFICATE")

        scope = cert.composition_scope
        if consumer_agent_id not in scope.permitted_consumers:
            return self._result("ABORT", "UNAUTHORIZED_CONSUMER")

        if scope.current_depth > 0 and not scope.allow_delegation:
            return self._result("NULL_ACTION", "DELEGATION_NOT_ALLOWED")

        if scope.current_depth > scope.max_delegation_depth:
            return self._result("NULL_ACTION", "DELEGATION_DEPTH_EXCEEDED")

        # Gate 2: evaluate H_now against the exact domain semantics bound by hash.
        predicate = self.registry.domain_predicate(cert.admitted_domain_hash)
        if predicate is None:
            return self._result("ABORT", "UNKNOWN_DOMAIN_SPEC")
        if not predicate(current_state):
            return self._result("NULL_ACTION", "DOMAIN_MISMATCH")

        # Gate 3: live assumptions fail closed. Missing telemetry is not evidence.
        for assumption in cert.environmental_assumptions:
            if environmental_state.get(assumption) is not True:
                return self._result("NULL_ACTION", "ASSUMPTION_FAILURE")

        # Positive warrants do not transitively survive delegation.
        if scope.current_depth > 0:
            if not composition_proof_hash or not transformation_hash:
                return self._result("NULL_ACTION", "COMPOSITION_PROOF_REQUIRED")
            if not self.registry.composition_authenticates(
                composition_proof_hash,
                cert,
                consumer_agent_id,
                transformation_hash,
            ):
                return self._result("NULL_ACTION", "INVALID_COMPOSITION_PROOF")

        if cert.disposition == "ABORT":
            return self._result("ABORT")
        if cert.disposition == "DEFER":
            return self._result("NULL_ACTION")

        violated = current_state.origin == "restricted" and current_state.destination == "external"
        return self._result("PROCEED", sink=True, violated=violated)
