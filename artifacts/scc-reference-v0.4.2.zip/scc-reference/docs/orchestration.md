# SCC Orchestration Layer

The `orchestration/` package demonstrates an execution architecture governed by the warrant-preservation calculus. It is intentionally framework-neutral and asynchronous. Consequential executors are reachable only through `SCCMiddleware.authorize_and_execute`; delegation and joins are recorded as topology, not silently converted into authorization.

The reference flow is `proposal -> evidence resolution -> scope/domain/assumption checks -> composition validation -> warrant -> execution`. A `NULL_ACTION` caused by missing environmental evidence may invoke an evidence acquirer and retry once. Other failures do not execute the proposed operation. The append-only ledger records proposals, evaluations, evidence requests, evidence acquisition, delegation, joins, and execution.

The package is a reference architecture, not a production scheduler. The in-memory ledger, registry, clocks, and evidence acquirer should be replaced by authenticated durable components in deployments. Framework adapters should implement the narrow protocol in `orchestration/protocol.py` rather than embedding framework-specific semantics into the SCC calculus.
