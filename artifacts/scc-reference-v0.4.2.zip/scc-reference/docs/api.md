# SCC Reference API Manual

## Conventions

This manual follows Unix manual-page conventions. Public interfaces are described in terms of a name, synopsis, arguments, return value, failure modes, invariants, side effects, and related interfaces. The Python package has no ambient network, filesystem, or process side effects. Registries are in-memory trust stores. A returned `PROCEED` is a derived warrant, while `NULL_ACTION` means that the available evidence does not justify positive continuation and `ABORT` means the presented certificate or evidence chain is invalid for the attempted evaluation.

The normative implementation is the Python source. Human-readable identifiers are labels; hashes are intended to bind semantics. In this reference implementation hashes are demonstration strings except for `neuroformal.runtime.compute_hash`, which computes SHA-256 over UTF-8 source text.

## scc_runtime.engine

### `SCCRuntimeEngine(current_time, proof_registry)`

Constructs an enforcement engine with an explicit evaluation clock and a trusted proof registry. The clock is injected rather than read from the host so tests and replays are deterministic. The registry is retained by reference.

### `SCCRuntimeEngine.evaluate_warrant(cert, current_state, consumer_agent_id, *, composition_proof_hash=None, transformation_hash=None, environmental_state=None)`

Evaluates a certificate through the SCC authorization gates. Gate ordering is significant: static factorization evidence is authenticated first; temporal and consumer scope are checked; delegation constraints are checked; the current state is tested against the domain semantics bound by the certificate; environmental assumptions are checked fail-closed; and delegated positive warrants require a registered composition proof. `environmental_state` is evidence, not configuration: a missing key is treated as unsatisfied. The method returns an `ExecutionResult` and never invokes an external sink itself. `sink_invoked=True` is a model of the decision that the demonstration sink would be invoked.

`ABORT` is returned for an unauthenticated proof obligation, stale certificate, unauthorized consumer, or unknown domain. `NULL_ACTION` is returned for a domain mismatch, missing/failed environmental evidence, forbidden or excessive delegation, missing composition proof, invalid composition proof, or a certificate disposition of `DEFER`. A certificate disposition of `ABORT` returns `ABORT`. A valid root or composition-certified `PROCEED` returns `PROCEED`.

### `SCCRuntimeEngine._result(status, reason=None, *, sink=False, violated=False)`

Internal constructor for normalized `ExecutionResult` objects. It performs no authorization reasoning. Callers should not use it as an authorization interface.

## scc_runtime.registry

### `TrustedProofRegistry()`

Creates an empty in-memory trust registry. Registration is explicit. The reference implementation does not persist, sign, revoke, or remotely resolve artifacts.

### `register_domain(domain_hash, predicate)`

Binds a domain identifier to executable membership semantics `History -> bool`. Re-registering the same identifier replaces the previous predicate. Production implementations should make this mapping immutable or content-addressed; mutation under a stable hash would violate the intended trust model.

### `register_proof(artifact)`

Registers a `VerifiedProofArtifact` under its `proof_hash`. Replacement semantics are dictionary replacement.

### `register_composition(artifact)`

Registers a `VerifiedCompositionArtifact` under its `proof_hash`.

### `proof_authenticates(cert)`

Returns true only when the registry contains the proof named by `cert.proof_hash`, the artifact is marked factorization-verified, and its property, projection, domain, and verifier version exactly match the certificate. This method authenticates bindings; it does not execute a theorem prover.

### `domain_predicate(domain_hash)`

Returns the registered domain predicate or `None` when the identifier is unknown.

### `composition_authenticates(proof_hash, cert, consumer_agent_id, transformation_hash)`

Returns true only when a registered composition artifact is marked verified and binds the parent certificate ID, consumer, transformation, property, domain, and verifier version supplied by the attempted delegation.

## scc_runtime.models

`History` is the minimal demonstration state with `origin` and `destination`. `CompositionScope` describes permitted consumers, delegation depth, parent provenance, and delegation/join policy. `ScopeCarryingCertificate` is immutable and binds property, projection, proof, domain, verifier, assumptions, time interval, composition scope, disposition, and issuance observations. `valid_interval()` rejects reversed intervals during Pydantic validation. `VerifiedProofArtifact` records a previously checked factorization obligation. `VerifiedCompositionArtifact` records a previously checked warrant-preserving transformation. `ExecutionResult` records the runtime decision and demonstration sink/invariant diagnostics.

## scc_runtime.legacy

### `legacy_boolean_runtime(current_state)`

Demonstrates the intentionally unsafe baseline in which local PASS is treated as transitively sufficient. It always returns `PROCEED` and models sink invocation. It exists only as a counterexample and MUST NOT be used as an authorization mechanism.

## neuroformal.runtime

### `compute_hash(content)`

Computes `sha256:` followed by the lowercase hexadecimal SHA-256 digest of the UTF-8 encoding of `content`. No Unicode normalization is performed, so canonically equivalent Unicode strings can hash differently.

### `NeuroFormalRuntime(registry)`

Constructs a neuro-formal evidence-chain evaluator backed by a `NeuroFormalProofRegistry`.

### `NeuroFormalRuntime.evaluate(*, source_content, translated_content, translation_cert, formal_proof_id)`

Attempts to derive a source-level warrant from a closed evidence chain. It verifies the source and target hashes, bridge direction, trusted translator version/configuration, registered bridge proof, property/domain bindings, source-domain membership, terminal proof existence and verification status, target binding, and target-property binding. It returns `PROCEED` only after every required link authenticates. Hash or binding substitution is classified as `ABORT`; insufficiency such as an unavailable bridge, wrong bridge direction, domain escape, or unavailable terminal proof produces `NULL_ACTION`.

### `NeuroFormalRuntime._null(reason)` / `_abort(reason)`

Internal normalized-result constructors. `_null` represents lack of sufficient warrant; `_abort` represents an invalid or inconsistent evidence chain.

## neuroformal.registry

### `NeuroFormalProofRegistry()`

Creates empty in-memory stores for terminal proofs, bridge proofs, source-domain predicates, and trusted translator identities.

### `trust_translator(translator_id, version_hash, configuration_hash)`

Binds a translator identity to the exact version and configuration accepted by the runtime. Re-registration replaces the prior binding.

### `translator_authenticates(translator_id, version_hash, configuration_hash)`

Returns true only if both version and configuration match the trusted bindings for the translator ID.

### `register_domain(domain_hash, predicate)` / `domain_predicate(domain_hash)`

Registers or resolves executable source-domain membership semantics.

### `register_formal_proof(artifact)` / `formal_proof(proof_id)`

Registers or resolves terminal formal proof artifacts.

### `register_faithfulness_proof(artifact)` / `faithfulness_proof(proof_hash)`

Registers or resolves property-relative bridge proofs connecting target-level truth back to source-level truth over an admitted domain.

## neuroformal.examples

### `defective_translate(source)`

Deliberately ignores its input and returns one constant formal stub. It therefore collapses authorized and unauthorized source programs into the same target fiber. This is test/demo code, not a translator implementation.

### `build_example()`

Constructs the complete neuro-formal demonstration fixture: a trusted translator identity, an authorized-only domain, a verified bridge artifact, a terminal proof over the common target stub, a translation certificate for the authorized source, and a runtime containing the resulting registry. Returns `(runtime, translation_certificate, terminal_proof_artifact)`.

## demo

### `make_registry()`

Builds the SCC demonstration registry containing the safe domain and valid factorization artifact.

### `make_cert(now, *, projection_hash=..., proof_hash=..., depth=0, consumers=None)`

Builds a demonstration certificate valid for one hour before and after `now`. `consumers=None` defaults to `['Sink']`. This is fixture construction, not certificate issuance logic.

### `show(label, result)`

Writes one formatted result row to standard output. It returns `None`.

### `run_test_matrix()`

Runs the legacy counterexample and seven-row SCC demonstration matrix. It writes diagnostics to standard output and returns `None`.

## Tests

Every `test_*` function under `tests/` is a pytest assertion of one documented contract. The tests intentionally have no return value. A failing assertion means the implementation no longer satisfies the named contract. `engine_and_registry()` is a fixture helper that returns a fresh deterministic engine and registry pair.

## orchestration

`orchestration` is the framework-neutral asynchronous execution layer. `SCCMiddleware.authorize_and_execute()` is the consequential-action boundary: it records a proposal, derives a warrant with `SCCRuntimeEngine`, optionally performs evidence reacquisition after an assumption-related `NULL_ACTION`, retries once, and invokes the supplied executor only after `PROCEED`. `ReferenceOrchestrator` adds explicit delegation, join, and concurrent-execution records without treating graph structure itself as authorization. `AppendOnlyLedger` provides an ordered provenance trace with no mutation or deletion API.
