# The Unified Calculus of Warrant Preservation

## Abstract

In secure autonomous and multi-agent systems, authorization claims can fail not because a downstream computation is incorrect, but because information required by the source-level property was erased before that computation occurred. The Scope-Carrying Certificate (SCC) framework therefore treats temporal truncation, structural projection, and representational translation as instances of a single problem: warrant non-preservation across information-losing transformations.

The governing principle is that **warrant cannot survive an information-losing transformation without explicit, independently verifiable preservation evidence**.

## 1. Generalized transformation rule

Let `z` be an informational object, let `Phi` be a property whose truth is needed to authorize an action, let `D` be the admitted domain, and let `T` be a transformation. `T` loses information whenever distinct source objects can share a representation:

$$
T(z_1)=T(z_2).
$$

A downstream representation can support a source-level decision only when the property is invariant over the fibers of `T` inside `D`:

$$
\forall z_1,z_2\in D:\quad
T(z_1)=T(z_2)\Longrightarrow \Phi(z_1)=\Phi(z_2).
$$

Equivalently, on the admitted domain there must exist a property on the representation, `hat(Phi)`, such that

$$
\Phi = \widehat{\Phi}\circ T.
$$

For positive authorization it is often sufficient to certify the directional bridge actually required by the decision. In a neuro-formal pipeline this is typically

$$
P_Y(\tau(x))\Longrightarrow P_X(x),
$$

not merely the opposite implication.

## 2. Three axes

### Temporal

The transformation is history reduction, for example

$$
H_{\le t}\mapsto M_t.
$$

The erased distinctions are differences among historical trajectories. A verifier that sees only `M_t` cannot derive a history-sensitive warrant unless the relevant property is invariant over histories collapsed into that memory state. Operational/archive separation and scoped causal evidence can preserve or recover the required support.

### Structural

The transformation is a projection of workflow geometry, for example

$$
G\mapsto \widehat{G},
$$

where a directed workflow graph is flattened into eventwise observations or another reduced representation. The erased distinctions include incidence, reachability, path multiplicity, delegation depth, joins, and cycles. Path-level closure laws and authenticated composition proofs provide the corresponding preservation evidence.

### Representational

The transformation is a source-to-formal translation

$$
X\xrightarrow{\tau}Y.
$$

The erased distinctions can include authorization modifiers, concurrency conditions, temporal requirements, aliasing, provenance, or other semantics. A terminal proof establishes a proposition about `y`; a source-level warrant additionally requires a property-relative bridge theorem over an admitted domain.

## 3. Evidence chain

The representational authorization chain is

$$
x\xrightarrow{C_\tau}y\xrightarrow{C_V}P_Y(y)
\xrightarrow{P_{\mathrm{bridge}}}P_X(x).
$$

The chain is closed only if the runtime source hash equals the translation certificate source hash, the translation target hash equals the terminal proof target hash, the source and target property identities agree across the bridge, the translator version/configuration is trusted, the source belongs to the bridge theorem's admitted domain, the bridge direction supports the requested inference, and the terminal proof artifact is independently authenticated.

A failure to derive a warrant is not itself proof that the contemplated action is unsafe. Where further evidence could resolve the deficiency, the reference runtime returns `NULL_ACTION` rather than manufacturing a positive or negative semantic judgment.

## 4. Anti-assertion mandate

Authorization decisions should consume evidence objects rather than caller-supplied claims about evidence. A field such as `is_faithful=True` or an argument such as `has_composition_proof=True` merely relocates the trust boundary. The reference implementation instead resolves proof artifacts from trusted registries and checks their bindings.

The rule is:

> Authorization consumes evidence objects, not epistemically meaningful booleans supplied by the party seeking authorization.

The demonstration models proof-checker results as fields inside trusted artifacts. In a production system those artifacts would themselves be authenticated outputs of proof checkers, signature systems, transparency logs, or other independently controlled verification mechanisms.

## 5. Consequence

The general non-inference is

$$
\operatorname{Warrant}_{\Phi}(T(z))
\not\Rightarrow
\operatorname{Warrant}_{\Phi}(z).
$$

The inference becomes legitimate only after establishing the appropriate preservation relation over the domain containing the current source object. This rule applies not only to the three demonstrations in this repository but also to summarization, retrieval, serialization, feature extraction, context-window reduction, delegation, lossy logging, and other transformations that can erase property-relevant distinctions.
