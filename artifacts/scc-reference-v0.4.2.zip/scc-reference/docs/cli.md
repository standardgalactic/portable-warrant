# SCC Unix Command Suite

The command suite treats standard input/output, deterministic hashes, stable exit statuses, and composability as first-class interfaces. All commands are also subcommands of `scc`.

` scc-hash FILE ` hashes UTF-8 content; `--json-input` canonicalizes JSON before hashing. `scc-check CERT` validates certificate shape. `scc-inspect CERT` emits the complete certificate plus derived delegation metadata. `scc-explain RESULT` maps reason codes to operator-facing explanations. `scc-trace CERT STATE --consumer ID` emits a diagnostic trace but deliberately leaves registry-dependent gates unresolved rather than fabricating authorization.

` scc-verify-chain CHAIN ` checks source/target property bindings and bridge direction in a JSON evidence-chain description. It is a structural diagnostic only. Registry-backed proof authentication remains mandatory at runtime.

` scc-fiber CASES ` partitions a finite JSON array by a transformation result field (`T` by default) and reports any fiber containing multiple property values (`Phi` by default). Exit 77 means a finite counterexample to property preservation was found.

` scc-translate SOURCE [-o TARGET] ` invokes the deliberately defective demonstration translator. `scc-prove TARGET` invokes the deliberately small demonstration terminal verifier. Neither should be confused with a production translator or proof kernel.

` scc-seal-decision DECISION --key KEYFILE ` attaches an HMAC-SHA256 authentication tag to a runtime decision. `scc-run --decision DECISION --key KEYFILE -- COMMAND ...` verifies that tag, requires `status=PROCEED` and `sink_invoked=true`, and then executes COMMAND directly without a shell. The HMAC wrapper demonstrates an authenticated handoff; production deployments should substitute an appropriate key-management/signature mechanism.

## Exit statuses

The tools follow sysexits-style conventions where useful: 0 success, 64 usage error, 65 malformed data, 66 missing input, 70 internal software error, and 77 refusal because authorization/evidence was not established. An authorized `scc-run` returns the child process status.
