# SCC Portable Kernel

Version 0.4.2 separates the warrant calculus from the Python implementation. A port is conforming only if it preserves the decision semantics and refuses to manufacture evidence that its runtime cannot authenticate.

## Seven operations

1. **CANONICALIZE** — produce a deterministic byte representation of an evidence object.
2. **HASH** — bind an identifier to those exact bytes using the profile's declared digest primitive.
3. **RESOLVE** — resolve an identifier to an authenticated evidence object, or fail closed.
4. **IN-DOMAIN** — evaluate the registered admitted-domain semantics against current state.
5. **ANCESTRY** — validate parentage, delegation depth, consumer scope, and required composition evidence.
6. **DERIVE** — return `PROCEED` only when all required gates are established; otherwise return a reasoned non-executing disposition.
7. **AUDIT** — append the evidence and decision identity needed for later replay.

These operations are semantic roles, not required function names. Host-specific cryptography, clocks, storage, and process execution sit outside the portable kernel.

## Minimal decision machine

For the shared conformance profile, proof failure yields `UNVERIFIED_PROOF_OBLIGATION`; domain failure yields `DOMAIN_MISMATCH`; a delegated action requiring but lacking composition evidence yields `COMPOSITION_PROOF_REQUIRED`; only the remaining path yields `PROCEED`.

The ordering is normative because it makes diagnostics deterministic when more than one prerequisite is absent.

## BASIC

BASIC demonstrates that the calculus does not depend on classes, exceptions, dictionaries, or a modern package manager. The 16-bit profile deliberately permits an external cryptographic verifier. If that service is unavailable, the correct result is `NULL_ACTION`, not an emulated success bit.

## Forth

Forth makes the authorization/effect boundary unusually visible. The portable word transforms gate results into `( warranted? reason )`; an execution word consumes the flag later. The proof system therefore does not hide an effect inside the predicate that decides whether the effect is warranted.

## Cross-language conformance

`ports/vectors/decisions.csv` and `ports/vectors/fibers.csv` are shared fixtures. A port must reproduce all decision rows and detect the lossy `external` fiber. More elaborate evidence-chain vectors may be added without changing the seven-operation kernel.

## Historical status

The BASIC and Forth ports are modern portability demonstrations presented in the repository's retro systems style. They are not claims that SCC, these files, or these interfaces existed historically on XENIX, Microsoft BASIC, or historical Forth systems.
