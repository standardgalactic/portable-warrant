# SCC 0.4.0 — Research Unix

The distribution treats SCC as a relocatable operating subsystem. `SCC_ROOT` selects the virtual root. The checked-in `etc/` and `var/` trees are safe fixtures and never require host `/etc` or `/var` access.

Utilities: `scc-fsck`, `scc-lint`, `scc-dump`, `scc-od`, `scc-tail`, and `scc-replay`. The SCC/1.0 interchange grammar is normative in SCC-3.
