# SCC 0.4.1 — XENIX Personality

The XENIX personality presents SCC as an imagined late-1980s OEM verification subsystem for an x86 Unix workstation. It is intentionally counterfactual. SCC is modern software and contains no Microsoft or SCO XENIX code.

Set `SCC_XENIX=1` to select the presentation convention. `SCC_ROOT` remains the virtual root, so initialization never writes the host `/etc` or `/var` trees.

The administrative vocabulary is deliberately terse: `sccinit` initializes a virtual subsystem tree; `sccstat` reports evidence-store status; `sccadm` performs administrative consistency checks; and `scclog` reads the audit stream. The existing modern commands remain authoritative and unchanged.

The personality uses a logical segment metaphor for certificate scope. Crossing a certificate boundary without a derivable warrant is a `SCOPE FAULT`, resolved as `NULL_ACTION` rather than a host process fault.
