# Design Rationale — Research Unix

## Non-transitive PROCEED
Positive authorization is a scoped derivation, not a capability that grows stronger by circulation. A downstream transformation therefore requires its own authenticated preservation argument.

## Absence of warrant is not danger
`NULL_ACTION` means that the available evidence does not derive the requested continuation. It does not assert that the continuation is unsafe.

## Evidence objects, not epistemic booleans
A boolean such as `is_faithful=True` hides provenance. SCC authorization resolves evidence artifacts and checks their bindings instead.

## Domains are semantics
Domain identifiers are meaningful only when bound to canonical predicate semantics. Renaming a domain must not alter what histories it admits.

## The framework is scoped too
SCC does not claim universal safety. Its conclusions are conditional on modeled transformations, registry integrity, canonicalization, cryptographic assumptions, domain definitions, implementation correctness, and the trusted verification base.

## XENIX personality and the constrained-machine model

SCC 0.4.1 includes an explicitly fictional XENIX/386 compatibility personality. It is an alternate-history presentation layer, not a claim that SCC contains, derives from, or is binary-compatible with Microsoft XENIX. Historical names are used to evoke the constrained, multi-user microcomputer environment in which byte-level inspectability, small utilities, flat files, process boundaries, and conservative resource accounting were natural engineering choices.

### Why flat files and content-addressed stores over relational databases?

The reference evidence store deliberately avoids a database dependency. Canonical byte streams can be inspected with ordinary tools, hashed independently, copied without an ORM, and reconstructed from the filesystem. This keeps the demonstrator's trusted surface small. The choice is inspired by constrained Unix systems, but its warrant-preservation semantics are modern and independent of the XENIX personality.

### Logical segmentation, not hardware segmentation

The XENIX personality describes certificate scope using a segment-descriptor metaphor: `scope = <base, limit, rights, generation>`. `base` identifies originating evidence, `limit` bounds domain or delegation, `rights` describes permitted consumers/dispositions, and `generation` prevents stale reuse. A failed crossing is reported as `SCOPE FAULT`. This is an SCC diagnostic term. It does not assert that the host kernel raised `SIGSEGV`, nor does it emulate x86 segmentation.

### Serial audit channels

`/dev/tty02` appears only as a commented compatibility example. The default is `audit_channel = "none"`; the reference subsystem never assumes that a serial device exists.
