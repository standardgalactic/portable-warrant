====================================================================
  SCOPE-CARRYING CERTIFICATE SUBSYSTEM (SCC) / RELEASE 0.4.1
  XENIX/386 COMPATIBILITY PERSONALITY

  Alternate-History OEM Systems Profile
  Target Personality: Intel 80286 / 80386 Protected-Mode UNIX
  Interface Tradition: V7 / System III / System V
  Document Class: Normative Architecture Specification

  NOTE: SCC is modern software. The XENIX personality is fictional
  presentation and claims no derivation from Microsoft XENIX source.
====================================================================

# SCC-3 — Evidence Chain Interchange

Status: Normative, version 1.0.

SCC3-1.1 SCC/1.0 is a deterministic line-oriented diagnostic interchange format. Records begin `SCC/1.0` and terminate with a line containing `.`.

```abnf
record = version 1*(field) terminator
version = "SCC/1.0" LF
field = key SP value LF
key = 1*(ALPHA / DIGIT / "-" / "_")
value = 1*(%x21-7E / SP)
terminator = "." LF
```

SCC3-2.1 Canonical JSON uses UTF-8, sorted object keys, and separators `,` and `:` without insignificant whitespace. SCC3-2.2 Hash inspection tools MUST expose the exact canonical bytes used as hash input.
