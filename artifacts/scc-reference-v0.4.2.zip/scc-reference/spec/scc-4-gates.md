====================================================================
  SCOPE-CARRYING CERTIFICATE SUBSYSTEM (SCC) / RELEASE 0.4.1
  XENIX/386 COMPATIBILITY PERSONALITY

  Alternate-History OEM Systems Profile
  Target Personality: Intel 80286 / 80386 Protected-Mode UNIX
  Interface Tradition: V7 / System III / System V
  Document Class: Normative Architecture Specification

  NOTE: SCC is modern software. The XENIX personality is fictional
  presentation and claims no derivation from Microsoft XENIX source.
====================================================================

# SCC-4 — Execution Gate Semantics

Status: Normative, version 1.0.

SCC4-1.1 `PROCEED` permits only the operation and scope explicitly warranted. SCC4-1.2 `NULL_ACTION` is an executable abstention and MAY acquire evidence. SCC4-1.3 `ABORT` terminates the contemplated continuation. SCC4-1.4 `DEFER` records that execution is not presently warranted.

SCC4-2.1 Not-warranted implies do-not-execute; it MUST NOT be reported as proof that the contemplated action is unsafe.
