====================================================================
  SCOPE-CARRYING CERTIFICATE SUBSYSTEM (SCC) / RELEASE 0.4.1
  XENIX/386 COMPATIBILITY PERSONALITY

  Alternate-History OEM Systems Profile
  Target Personality: Intel 80286 / 80386 Protected-Mode UNIX
  Interface Tradition: V7 / System III / System V
  Document Class: Normative Architecture Specification

  NOTE: SCC is modern software. The XENIX personality is fictional
  presentation and claims no derivation from Microsoft XENIX source.
====================================================================

# SCC-2 — Warrant Preservation Protocol

Status: Normative, version 1.0.

SCC2-1.1 For admitted domain D, a transformation T preserves a property Φ only if for all z1,z2 in D, T(z1)=T(z2) implies Φ(z1)=Φ(z2).

SCC2-2.1 Positive warrants MUST be non-transitive by default. SCC2-2.2 Delegation or composition MUST resolve authenticated preservation evidence.

SCC2-3.1 Runtime authorization SHALL require authenticated proof identity, current domain membership, and valid composition derivation.

SCC2-4.3.7 A downstream PROCEED MUST NOT be inferred solely from an upstream PROCEED.
