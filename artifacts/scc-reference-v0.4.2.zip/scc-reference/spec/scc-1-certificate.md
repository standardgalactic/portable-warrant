====================================================================
  SCOPE-CARRYING CERTIFICATE SUBSYSTEM (SCC) / RELEASE 0.4.1
  XENIX/386 COMPATIBILITY PERSONALITY

  Alternate-History OEM Systems Profile
  Target Personality: Intel 80286 / 80386 Protected-Mode UNIX
  Interface Tradition: V7 / System III / System V
  Document Class: Normative Architecture Specification

  NOTE: SCC is modern software. The XENIX personality is fictional
  presentation and claims no derivation from Microsoft XENIX source.
====================================================================

# SCC-1 — Scope-Carrying Certificate Format

Status: Normative, version 1.0.

## 1. Scope
SCC1-1.1 A certificate MUST bind property, projection, admitted domain, proof artifact, validity interval, consumer scope, delegation state, and disposition.

SCC1-1.2 Human-readable names MUST NOT substitute for content identities where authorization depends on semantics.

## 2. Provenance
SCC1-2.1 Parent certificate identifiers MUST be retained across derivation. SCC1-2.2 A child validity interval MUST NOT exceed the interval warranted by its ancestors.

## 3. Failure
SCC1-3.1 Missing or unauthenticated proof material MUST fail closed. Absence of warrant MUST NOT be represented as proof of unsafety.
