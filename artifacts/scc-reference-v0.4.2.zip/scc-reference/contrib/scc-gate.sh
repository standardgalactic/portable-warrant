#!/bin/sh
# Minimal POSIX shell gate. Usage: scc-gate.sh DECISION KEY -- command ...
set -eu
decision=$1; key=$2; shift 2
[ "${1:-}" = "--" ] && shift
exec scc-run --decision "$decision" --key "$key" -- "$@"
