"""tests/test_runtime.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from datetime import datetime, timedelta

from demo import DOMAIN_SAFE, PROPERTY, PROJECTION_BAD, TRANSFORM_A_B, VERIFIER, make_cert, make_registry
from scc_runtime import History, SCCRuntimeEngine, VerifiedCompositionArtifact

NOW = datetime(2026, 9, 25, 12, 0, 0)
SAFE = History(origin="public", destination="external")
UNSAFE = History(origin="restricted", destination="external")


def engine_and_registry():
    """Construct a fresh deterministic SCC engine and registry for a test.

    Returns a two-tuple containing the engine and registry; no global state is reused between tests.
    """
    registry = make_registry()
    return SCCRuntimeEngine(NOW, registry), registry


def test_fiber_counterexample_rejected():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    cert = make_cert(NOW, projection_hash=PROJECTION_BAD, proof_hash="missing")
    r = engine.evaluate_warrant(cert, UNSAFE, "Sink", environmental_state={"secure_channel": True})
    assert (r.status, r.reason_code) == ("ABORT", "UNVERIFIED_PROOF_OBLIGATION")


def test_valid_root_proceeds():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    r = engine.evaluate_warrant(make_cert(NOW), SAFE, "Sink", environmental_state={"secure_channel": True})
    assert r.status == "PROCEED" and r.sink_invoked and not r.global_invariant_violated


def test_domain_escape_abstains():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    r = engine.evaluate_warrant(make_cert(NOW), UNSAFE, "Sink", environmental_state={"secure_channel": True})
    assert (r.status, r.reason_code) == ("NULL_ACTION", "DOMAIN_MISMATCH")


def test_missing_composition_proof_abstains():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    cert = make_cert(NOW, depth=1, consumers=["Agent_B"])
    r = engine.evaluate_warrant(cert, SAFE, "Agent_B", environmental_state={"secure_channel": True})
    assert (r.status, r.reason_code) == ("NULL_ACTION", "COMPOSITION_PROOF_REQUIRED")


def test_missing_environment_evidence_fails_closed():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    r = engine.evaluate_warrant(make_cert(NOW), SAFE, "Sink")
    assert (r.status, r.reason_code) == ("NULL_ACTION", "ASSUMPTION_FAILURE")


def test_stale_certificate_aborts():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, _ = engine_and_registry()
    cert = make_cert(NOW).model_copy(update={"validity_interval": (NOW - timedelta(hours=5), NOW - timedelta(hours=2))})
    r = engine.evaluate_warrant(cert, SAFE, "Sink", environmental_state={"secure_channel": True})
    assert (r.status, r.reason_code) == ("ABORT", "STALE_CERTIFICATE")


def test_fully_certified_chain_proceeds():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    engine, registry = engine_and_registry()
    cert = make_cert(NOW, depth=1, consumers=["Agent_B"])
    registry.register_composition(VerifiedCompositionArtifact(
        proof_hash="composition-proof",
        parent_certificate_id=cert.certificate_id,
        consumer_agent_id="Agent_B",
        transformation_hash=TRANSFORM_A_B,
        property_hash=PROPERTY,
        domain_hash=DOMAIN_SAFE,
        verifier_version=VERIFIER,
        composition_verified=True,
    ))
    r = engine.evaluate_warrant(
        cert, SAFE, "Agent_B",
        composition_proof_hash="composition-proof",
        transformation_hash=TRANSFORM_A_B,
        environmental_state={"secure_channel": True},
    )
    assert r.status == "PROCEED" and r.sink_invoked
