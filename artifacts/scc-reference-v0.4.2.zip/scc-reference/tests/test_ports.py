from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]

def derive(proof, domain, need_comp, comp):
    if not proof: return "NULL_ACTION", "UNVERIFIED_PROOF_OBLIGATION"
    if not domain: return "NULL_ACTION", "DOMAIN_MISMATCH"
    if need_comp and not comp: return "NULL_ACTION", "COMPOSITION_PROOF_REQUIRED"
    return "PROCEED", "OK"

def test_shared_decision_vectors():
    with (ROOT / "ports/vectors/decisions.csv").open() as f:
        for row in csv.DictReader(f):
            got = derive(*(row[k] == "1" for k in ("proof_ok", "domain_ok", "composition_required", "composition_ok")))
            assert got == (row["expected_disposition"], row["expected_reason"]), row["id"]

def test_shared_fiber_vector_contains_violation():
    fibers = {}
    with (ROOT / "ports/vectors/fibers.csv").open() as f:
        for row in csv.DictReader(f):
            fibers.setdefault(row["t_value"], set()).add(row["phi_value"])
    assert fibers["external"] == {"0", "1"}

def test_ports_do_not_self_certify_missing_crypto():
    basic = (ROOT / "ports/basic/STORE.BAS").read_text()
    forth = (ROOT / "ports/forth/store.fs").read_text()
    assert "WARRANT NOT DERIVED" in basic
    assert "false UNVERIFIED-PROOF" in forth

def test_port_docs_mark_historical_status():
    text = (ROOT / "docs/porting-guide.md").read_text()
    assert "not claims" in text.lower()
