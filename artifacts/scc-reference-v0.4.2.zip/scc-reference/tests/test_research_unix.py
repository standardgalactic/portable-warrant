import json, hashlib
from pathlib import Path
from scc_cli.retro import canonical_bytes, parse_protocol, scan_store

def test_canonical_bytes_sorted():
    assert canonical_bytes({"b":2,"a":1}) == b'{"a":1,"b":2}'

def test_protocol_fixture():
    p=Path("fixtures/protocol/cert-A-001.scc")
    d=parse_protocol(p.read_text())
    assert d["CERT"] == "cert-A-001" and d["DISPOSITION"] == "PROCEED"

def test_virtual_store_scans():
    s=scan_store(Path('.').resolve())
    assert s['broken'] == []

def test_spec_requirement_ids_present():
    assert 'SCC2-4.3.7' in Path('spec/scc-2-preservation.md').read_text()
