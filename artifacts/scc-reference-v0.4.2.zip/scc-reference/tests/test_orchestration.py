"""Tests for the asynchronous SCC orchestration layer."""
import asyncio
from datetime import datetime
from demo import DOMAIN_SAFE, PROPERTY, TRANSFORM_A_B, VERIFIER, make_cert, make_registry
from orchestration import ActionProposal, AppendOnlyLedger, ReferenceOrchestrator, SCCMiddleware
from scc_runtime import History, SCCRuntimeEngine, VerifiedCompositionArtifact

NOW = datetime(2026, 9, 25, 12, 0, 0)
SAFE = History(origin="public", destination="external")

async def executor(p):
    return {"ok": p.action_id}

def setup(acquirer=None):
    registry = make_registry(); ledger = AppendOnlyLedger(); engine = SCCRuntimeEngine(NOW, registry)
    return ReferenceOrchestrator(SCCMiddleware(engine, ledger, acquirer), ledger), registry, ledger

def test_root_action_executes_and_is_logged():
    orch, _, ledger = setup()
    p = ActionProposal(action_id="a1", agent_id="A", consumer_id="Sink", operation="emit")
    r = asyncio.run(orch.run(p, make_cert(NOW), SAFE, executor, environmental_state={"secure_channel": True}))
    assert r.executed and r.status == "PROCEED"
    assert [e.event_type for e in ledger.for_action("a1")] == ["PROPOSED", "EVALUATED", "EXECUTED"]

def test_delegation_without_composition_abstains():
    orch, _, ledger = setup()
    p = ActionProposal(action_id="a2", agent_id="B", consumer_id="Agent_B", operation="emit", transformation_hash=TRANSFORM_A_B)
    cert = make_cert(NOW, depth=1, consumers=["Agent_B"])
    r = asyncio.run(orch.run(p, cert, SAFE, executor, environmental_state={"secure_channel": True}))
    assert not r.executed and r.reason_code == "COMPOSITION_PROOF_REQUIRED"

def test_certified_delegation_executes():
    orch, registry, _ = setup()
    cert = make_cert(NOW, depth=1, consumers=["Agent_B"])
    registry.register_composition(VerifiedCompositionArtifact(proof_hash="cp", parent_certificate_id=cert.certificate_id,
        consumer_agent_id="Agent_B", transformation_hash=TRANSFORM_A_B, property_hash=PROPERTY,
        domain_hash=DOMAIN_SAFE, verifier_version=VERIFIER, composition_verified=True))
    p = ActionProposal(action_id="a3", agent_id="B", consumer_id="Agent_B", operation="emit", transformation_hash=TRANSFORM_A_B)
    r = asyncio.run(orch.run(p, cert, SAFE, executor, composition_proof_hash="cp", environmental_state={"secure_channel": True}))
    assert r.executed

def test_null_action_reacquires_evidence_and_retries():
    async def acquire(p, reason): return {"secure_channel": True}
    orch, _, ledger = setup(acquire)
    p = ActionProposal(action_id="a4", agent_id="A", consumer_id="Sink", operation="emit")
    r = asyncio.run(orch.run(p, make_cert(NOW), SAFE, executor, environmental_state={}))
    assert r.executed
    kinds = [e.event_type for e in ledger.for_action("a4")]
    assert "EVIDENCE_REQUESTED" in kinds and "EVIDENCE_ACQUIRED" in kinds

def test_concurrent_actions_remain_individually_governed():
    orch, _, _ = setup()
    cert = make_cert(NOW)
    ps = [ActionProposal(action_id=f"c{i}", agent_id="A", consumer_id="Sink", operation="emit") for i in range(2)]
    async def go():
        return await orch.run_concurrent([orch.run(p, cert, SAFE, executor, environmental_state={"secure_channel": True}) for p in ps])
    results = asyncio.run(go())
    assert all(r.executed for r in results)
