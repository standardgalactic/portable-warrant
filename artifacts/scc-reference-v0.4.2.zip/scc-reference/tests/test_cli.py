"""Tests for Unix-style SCC command wrappers."""
import json
from pathlib import Path
from scc_cli.main import main

def test_fiber_detects_violation(tmp_path):
    p=tmp_path/'cases.json'; p.write_text(json.dumps([{"T":"same","Phi":True},{"T":"same","Phi":False}]))
    assert main(["fiber",str(p)]) == 77

def test_fiber_accepts_constant_property(tmp_path):
    p=tmp_path/'cases.json'; p.write_text(json.dumps([{"T":"same","Phi":True},{"T":"same","Phi":True}]))
    assert main(["fiber",str(p)]) == 0

def test_hash_is_stable(tmp_path):
    p=tmp_path/'x'; p.write_text('abc')
    assert main(["hash",str(p)]) == 0

def test_run_refuses_unauthenticated_decision(tmp_path):
    d=tmp_path/'d.json'; d.write_text(json.dumps({"status":"PROCEED","sink_invoked":True}))
    key=tmp_path/'key'; key.write_bytes(b"test-secret")
    assert main(["run","--decision",str(d),"--key",str(key),"python","-c","raise SystemExit(9)"]) == 77

def test_run_executes_authenticated_warrant(tmp_path):
    from scc_cli.main import _decision_tag
    key=tmp_path/'key'; key.write_bytes(b"test-secret")
    obj={"status":"PROCEED","sink_invoked":True}; obj["auth_tag"]=_decision_tag(obj,key.read_bytes())
    d=tmp_path/'d.json'; d.write_text(json.dumps(obj))
    assert main(["run","--decision",str(d),"--key",str(key),"python","-c","raise SystemExit(0)"]) == 0
