"""tests/test_neuroformal.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from neuroformal.examples import AUTHORIZED_SOURCE, UNAUTHORIZED_SOURCE, build_example, defective_translate
from neuroformal.models import TranslationCertificate
from neuroformal.runtime import compute_hash


def test_authorized_source_derives_warrant():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    result = runtime.evaluate(
        source_content=AUTHORIZED_SOURCE,
        translated_content=defective_translate(AUTHORIZED_SOURCE),
        translation_cert=cert,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "PROCEED"
    assert result.source_warrant_derived is True


def test_same_target_does_not_launder_unauthorized_source():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    assert defective_translate(AUTHORIZED_SOURCE) == defective_translate(UNAUTHORIZED_SOURCE)

    # A certificate honestly bound to x1 cannot use the x0-only bridge domain to derive a warrant.
    cert_x1 = cert.model_copy(update={"source_artifact_hash": compute_hash(UNAUTHORIZED_SOURCE)})
    result = runtime.evaluate(
        source_content=UNAUTHORIZED_SOURCE,
        translated_content=defective_translate(UNAUTHORIZED_SOURCE),
        translation_cert=cert_x1,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "NULL_ACTION"
    assert result.reason_code == "TRANSLATION_DOMAIN_MISMATCH"
    assert result.source_warrant_derived is False


def test_source_substitution_is_detected():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    result = runtime.evaluate(
        source_content=UNAUTHORIZED_SOURCE,
        translated_content=defective_translate(UNAUTHORIZED_SOURCE),
        translation_cert=cert,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "ABORT"
    assert result.reason_code == "SOURCE_HASH_MISMATCH"


def test_missing_bridge_proof_blocks_authorization():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    forged = cert.model_copy(update={"faithfulness_proof_hash": "sha256:missing"})
    result = runtime.evaluate(
        source_content=AUTHORIZED_SOURCE,
        translated_content=defective_translate(AUTHORIZED_SOURCE),
        translation_cert=forged,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "NULL_ACTION"
    assert result.reason_code == "UNVERIFIED_TRANSLATION_FAITHFULNESS"


def test_wrong_bridge_direction_blocks_positive_authorization():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    wrong = cert.model_copy(update={"direction": "SOURCE_IMPLIES_TARGET"})
    result = runtime.evaluate(
        source_content=AUTHORIZED_SOURCE,
        translated_content=defective_translate(AUTHORIZED_SOURCE),
        translation_cert=wrong,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "NULL_ACTION"
    assert result.reason_code == "INVALID_BRIDGE_DIRECTION"


def test_target_substitution_is_detected():
    """Regression test for the contract named by this function.

    The function returns no value.  Pytest treats an AssertionError as failure; success means the named authorization or evidence-chain invariant remains satisfied.
    """
    runtime, cert, terminal = build_example()
    result = runtime.evaluate(
        source_content=AUTHORIZED_SOURCE,
        translated_content="(assert different_target)",
        translation_cert=cert,
        formal_proof_id=terminal.proof_id,
    )
    assert result.status == "ABORT"
    assert result.reason_code == "TARGET_HASH_MISMATCH"
