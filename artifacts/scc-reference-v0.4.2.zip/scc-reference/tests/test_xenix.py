from argparse import Namespace
from scc_cli.xenix import cmd_xenix_init, cmd_xenix_stat, cmd_xenix_adm, scope_fault

def test_xenix_init_is_relocatable(tmp_path):
    a=Namespace(root=str(tmp_path),quiet=True,force=False)
    assert cmd_xenix_init(a)==0
    assert (tmp_path/'etc/scc/scc.conf').exists()
    assert (tmp_path/'var/spool/scc/audit').is_dir()
    assert not (tmp_path/'etc/scc/scc.conf').read_text().find('audit_channel = "none"') < 0

def test_xenix_admin_clean(tmp_path):
    cmd_xenix_init(Namespace(root=str(tmp_path),quiet=True,force=False))
    assert cmd_xenix_adm(Namespace(root=str(tmp_path),quiet=True))==0
    assert cmd_xenix_stat(Namespace(root=str(tmp_path)))==0

def test_scope_fault_is_logical():
    s=scope_fault('composition proof required')
    assert s.startswith('SCOPE FAULT:')
    assert 'null action' in s
