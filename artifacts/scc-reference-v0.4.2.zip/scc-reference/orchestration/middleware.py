"""SCC authorization middleware for asynchronous action execution."""
from __future__ import annotations
from typing import Awaitable, Callable, Dict, Optional, Any
from scc_runtime import History, SCCRuntimeEngine, ScopeCarryingCertificate
from .ledger import AppendOnlyLedger
from .models import ActionProposal, OrchestrationOutcome

EvidenceAcquirer = Callable[[ActionProposal, str], Awaitable[Dict[str, bool]]]
Executor = Callable[[ActionProposal], Awaitable[Any]]

class SCCMiddleware:
    """Place a consequential executor behind SCC warrant derivation."""
    def __init__(self, engine: SCCRuntimeEngine, ledger: AppendOnlyLedger, evidence_acquirer: Optional[EvidenceAcquirer] = None):
        self.engine = engine
        self.ledger = ledger
        self.evidence_acquirer = evidence_acquirer

    async def authorize_and_execute(self, proposal: ActionProposal, cert: ScopeCarryingCertificate,
                                    state: History, executor: Executor, *, composition_proof_hash: Optional[str] = None,
                                    environmental_state: Optional[Dict[str, bool]] = None,
                                    retry_after_evidence: bool = True) -> OrchestrationOutcome:
        """Evaluate a proposal, optionally reacquire missing evidence, and execute only on PROCEED."""
        self.ledger.append("PROPOSED", proposal.action_id, proposal.agent_id, {"consumer": proposal.consumer_id})
        result = self.engine.evaluate_warrant(cert, state, proposal.consumer_id,
            composition_proof_hash=composition_proof_hash, transformation_hash=proposal.transformation_hash,
            environmental_state=environmental_state)
        self.ledger.append("EVALUATED", proposal.action_id, proposal.agent_id,
                           {"status": result.status, "reason_code": result.reason_code})

        if result.status == "NULL_ACTION" and result.reason_code == "ASSUMPTION_FAILURE" and self.evidence_acquirer and retry_after_evidence:
            self.ledger.append("EVIDENCE_REQUESTED", proposal.action_id, proposal.agent_id, {"reason": result.reason_code})
            acquired = await self.evidence_acquirer(proposal, result.reason_code)
            self.ledger.append("EVIDENCE_ACQUIRED", proposal.action_id, proposal.agent_id, {"keys": sorted(acquired)})
            merged = dict(environmental_state or {})
            merged.update(acquired)
            result = self.engine.evaluate_warrant(cert, state, proposal.consumer_id,
                composition_proof_hash=composition_proof_hash, transformation_hash=proposal.transformation_hash,
                environmental_state=merged)
            self.ledger.append("EVALUATED", proposal.action_id, proposal.agent_id,
                               {"status": result.status, "reason_code": result.reason_code, "retry": True})

        if result.status != "PROCEED":
            event = "NULL_ACTION" if result.status == "NULL_ACTION" else "NULL_ACTION"
            self.ledger.append(event, proposal.action_id, proposal.agent_id, {"reason": result.reason_code, "status": result.status})
            return OrchestrationOutcome(status=result.status, executed=False, reason_code=result.reason_code)

        value = await executor(proposal)
        self.ledger.append("EXECUTED", proposal.action_id, proposal.agent_id, {"operation": proposal.operation})
        return OrchestrationOutcome(status="PROCEED", executed=True, value=value)
