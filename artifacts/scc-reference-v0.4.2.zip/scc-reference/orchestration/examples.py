"""Executable orchestration examples and adversarial workflows."""
from __future__ import annotations
from datetime import datetime
from typing import Any
from demo import make_cert, make_registry, TRANSFORM_A_B
from scc_runtime import History, SCCRuntimeEngine, VerifiedCompositionArtifact
from .ledger import AppendOnlyLedger
from .middleware import SCCMiddleware
from .models import ActionProposal
from .orchestrator import ReferenceOrchestrator

async def echo_executor(proposal: ActionProposal) -> dict[str, Any]:
    """Benign example executor used to prove that warranted actions remain executable."""
    return {"operation": proposal.operation, "payload": proposal.payload}

async def secure_channel_acquirer(proposal: ActionProposal, reason: str) -> dict[str, bool]:
    """Reference NULL_ACTION handler that reacquires secure-channel telemetry."""
    return {"secure_channel": True}

async def build_example(now: datetime):
    """Construct a deterministic orchestrator, registry, and ledger for examples and tests."""
    registry = make_registry()
    engine = SCCRuntimeEngine(now, registry)
    ledger = AppendOnlyLedger()
    middleware = SCCMiddleware(engine, ledger, secure_channel_acquirer)
    return ReferenceOrchestrator(middleware, ledger), registry, ledger
