"""Framework-neutral adapter protocol for SCC-governed orchestrators."""
from __future__ import annotations
from typing import Any, Protocol
from .models import ActionProposal, OrchestrationOutcome

class OrchestrationAdapter(Protocol):
    """Minimal boundary that external agent frameworks can implement."""
    async def before_action(self, proposal: ActionProposal) -> None: ...
    async def execute(self, proposal: ActionProposal) -> Any: ...
    async def after_action(self, proposal: ActionProposal, outcome: OrchestrationOutcome) -> None: ...
