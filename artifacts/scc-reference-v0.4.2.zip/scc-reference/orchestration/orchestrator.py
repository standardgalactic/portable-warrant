"""Minimal asynchronous reference orchestrator governed by SCC middleware."""
from __future__ import annotations
import asyncio
from typing import Any, Awaitable, Callable, Iterable, Sequence
from scc_runtime import History, ScopeCarryingCertificate
from .ledger import AppendOnlyLedger
from .middleware import SCCMiddleware
from .models import ActionProposal, OrchestrationOutcome

class ReferenceOrchestrator:
    """Coordinate actions, delegations, and joins without bypassing the SCC boundary."""
    def __init__(self, middleware: SCCMiddleware, ledger: AppendOnlyLedger):
        self.middleware = middleware
        self.ledger = ledger

    async def run(self, proposal: ActionProposal, cert: ScopeCarryingCertificate, state: History,
                  executor: Callable[[ActionProposal], Awaitable[Any]], **kwargs: Any) -> OrchestrationOutcome:
        """Run one proposed action through middleware and return its outcome."""
        return await self.middleware.authorize_and_execute(proposal, cert, state, executor, **kwargs)

    def delegate(self, parent: ActionProposal, child: ActionProposal) -> None:
        """Record an explicit delegation edge; this record does not itself derive a warrant."""
        self.ledger.append("DELEGATED", child.action_id, parent.agent_id,
                           {"parent_action_id": parent.action_id, "child_agent": child.agent_id})

    def join(self, action_id: str, agent_id: str, parent_action_ids: Sequence[str]) -> None:
        """Record a workflow join while leaving join authorization to evidence validation."""
        self.ledger.append("JOINED", action_id, agent_id, {"parents": list(parent_action_ids)})

    async def run_concurrent(self, jobs: Iterable[Awaitable[OrchestrationOutcome]]) -> list[OrchestrationOutcome]:
        """Execute independent SCC-governed jobs concurrently and preserve their individual outcomes."""
        return list(await asyncio.gather(*jobs))
