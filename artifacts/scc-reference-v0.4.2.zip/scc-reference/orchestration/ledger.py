"""Append-only in-memory provenance ledger for orchestration experiments."""
from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, Iterable, List
from .models import LedgerEvent

class AppendOnlyLedger:
    """Record ordered orchestration events without mutation or deletion APIs."""
    def __init__(self) -> None:
        self._events: List[LedgerEvent] = []

    def append(self, event_type: str, action_id: str, agent_id: str, details: Dict[str, Any] | None = None) -> LedgerEvent:
        """Append one event and return the immutable ledger record."""
        event = LedgerEvent(sequence=len(self._events), timestamp=datetime.now(), event_type=event_type,
                            action_id=action_id, agent_id=agent_id, details=details or {})
        self._events.append(event)
        return event

    def events(self) -> tuple[LedgerEvent, ...]:
        """Return an immutable snapshot of all ledger events in sequence order."""
        return tuple(self._events)

    def for_action(self, action_id: str) -> tuple[LedgerEvent, ...]:
        """Return the ordered ledger projection associated with one action identifier."""
        return tuple(e for e in self._events if e.action_id == action_id)
