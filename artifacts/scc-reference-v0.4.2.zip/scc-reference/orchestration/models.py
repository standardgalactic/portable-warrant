"""Data models for the asynchronous SCC reference orchestrator."""
from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field

class ActionProposal(BaseModel):
    """A proposed consequential operation awaiting warrant derivation."""
    model_config = ConfigDict(frozen=True)
    action_id: str
    agent_id: str
    consumer_id: str
    operation: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    transformation_hash: Optional[str] = None

class LedgerEvent(BaseModel):
    """Immutable event appended to the orchestration provenance ledger."""
    model_config = ConfigDict(frozen=True)
    sequence: int = Field(ge=0)
    timestamp: datetime
    event_type: Literal[
        "PROPOSED", "EVALUATED", "EXECUTED", "NULL_ACTION",
        "EVIDENCE_REQUESTED", "EVIDENCE_ACQUIRED", "DELEGATED", "JOINED"
    ]
    action_id: str
    agent_id: str
    details: Dict[str, Any] = Field(default_factory=dict)

class OrchestrationOutcome(BaseModel):
    """Result of passing a proposal through SCC middleware."""
    status: Literal["PROCEED", "NULL_ACTION", "ABORT"]
    executed: bool
    reason_code: Optional[str] = None
    value: Any = None
