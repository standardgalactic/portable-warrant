"""Research-Unix diagnostic utilities for SCC stores and ledgers."""
from __future__ import annotations
import json, os, sys, time, hashlib
from pathlib import Path
from .common import canonical_json, EX_OK, EX_DATAERR, EX_NOPERM, EX_NOINPUT

def root_path(value=None):
    """Resolve the relocatable SCC root without touching host /etc or /var."""
    return Path(value or os.environ.get("SCC_ROOT", ".")).resolve()

def canonical_bytes(obj):
    """Return the UTF-8 canonical JSON octets authenticated by SCC hashes."""
    return canonical_json(obj).encode("utf-8")

def cmd_dump(a):
    try: obj=json.loads(Path(a.file).read_text()) if a.file!='-' else json.load(sys.stdin)
    except Exception as e: print(f"scc-dump: {e}",file=sys.stderr); return EX_DATAERR
    sys.stdout.buffer.write(canonical_bytes(obj)+b"\n"); return EX_OK

def cmd_od(a):
    try: obj=json.loads(Path(a.file).read_text()) if a.file!='-' else json.load(sys.stdin); b=canonical_bytes(obj)
    except Exception as e: print(f"scc-od: {e}",file=sys.stderr); return EX_DATAERR
    for off in range(0,len(b),16):
        c=b[off:off+16]; hx=' '.join(f'{x:02x}' for x in c); asc=''.join(chr(x) if 32<=x<127 else '.' for x in c)
        print(f'{off:08x}  {hx:<47}  |{asc}|')
    return EX_OK

def _json_files(p): return sorted(p.rglob('*.json')) if p.exists() else []

def scan_store(root):
    """Scan the virtual SCC hierarchy and return consistency diagnostics."""
    certdir=root/'var/lib/scc/certificates'; proofdir=root/'var/lib/scc/proofs'
    certs={}; proofs={}; broken=[]
    for f in _json_files(proofdir):
        try:
            d=json.loads(f.read_text()); proofs[d.get('proof_hash',f.stem)]=d
        except Exception as e: broken.append({'file':str(f),'reason':'invalid-json'})
    for f in _json_files(certdir):
        try:
            d=json.loads(f.read_text()); certs[d.get('certificate_id',f.stem)]=d
        except Exception: broken.append({'file':str(f),'reason':'invalid-json'})
    for cid,c in certs.items():
        ph=c.get('proof_hash');
        if ph and ph not in proofs: broken.append({'certificate':cid,'reason':'dangling-proof','proof_hash':ph})
        parent=(c.get('composition_scope') or {}).get('parent_certificate_id')
        if parent and parent not in certs: broken.append({'certificate':cid,'reason':'dangling-parent','parent':parent})
    refs={c.get('proof_hash') for c in certs.values()}; orphan=[k for k in proofs if k not in refs]
    return {'proofs':len(proofs),'certificates':len(certs),'broken':broken,'orphan_proofs':orphan}

def cmd_fsck(a):
    root=root_path(a.root); s=scan_store(root)
    if not a.quiet:
        print('** Phase 1 - Check proof objects'); print('** Phase 2 - Check certificate bindings'); print('** Phase 3 - Check parentage'); print('** Phase 4 - Check composition closure'); print('** Phase 5 - Check orphaned evidence'); print()
        print(f"{s['proofs']} proof artifacts"); print(f"{s['certificates']} certificates"); print(f"{len(s['broken'])} broken references"); print(f"{len(s['orphan_proofs'])} unreachable artifacts"); print(); print('SCC FILE SYSTEM IS CLEAN' if not s['broken'] else 'SCC FILE SYSTEM HAS ERRORS')
    return EX_OK if not s['broken'] else EX_NOPERM

def cmd_lint(a):
    root=root_path(a.root); s=scan_store(root); issues=list(s['broken'])
    domdir=root/'etc/scc/domains.d'
    for f in _json_files(root/'var/lib/scc/certificates'):
        try: c=json.loads(f.read_text()); did=c.get('admitted_domain_hash') or c.get('admitted_domain_spec')
        except Exception: continue
        if did and not any(did in p.read_text(errors='ignore') for p in _json_files(domdir)): issues.append({'file':str(f),'reason':'domain-without-definition','domain':did})
    for x in issues: print(json.dumps(x,sort_keys=True))
    if not a.quiet: print(f'scc-lint: {len(issues)} issue(s)',file=sys.stderr)
    return EX_OK if not issues else EX_NOPERM

def cmd_tail(a):
    p=Path(a.file);
    if not p.exists(): print(f'scc-tail: {p}: not found',file=sys.stderr); return EX_NOINPUT
    lines=p.read_text().splitlines(); n=max(0,a.lines)
    for x in lines[-n:]: print(x)
    if a.follow:
        with p.open() as f:
            f.seek(0,2)
            try:
                while True:
                    line=f.readline()
                    if line: print(line,end='',flush=True)
                    else: time.sleep(.25)
            except KeyboardInterrupt: pass
    return EX_OK

def cmd_replay(a):
    p=Path(a.file); bad=[]; count=0
    try:
        for no,line in enumerate(p.read_text().splitlines(),1):
            if not line.strip(): continue
            count+=1; d=json.loads(line)
            # A replayable record may carry canonical input plus its recorded digest.
            if 'input' in d and 'input_sha256' in d:
                got=hashlib.sha256(canonical_bytes(d['input'])).hexdigest()
                if got!=d['input_sha256']: bad.append({'line':no,'reason':'input-digest-mismatch'})
            if d.get('status')=='PROCEED' and d.get('sink_invoked') is not True: bad.append({'line':no,'reason':'inconsistent-proceed'})
    except Exception as e: print(f'scc-replay: {e}',file=sys.stderr); return EX_DATAERR
    print(json.dumps({'records':count,'reproducible':not bad,'mismatches':bad},sort_keys=True))
    return EX_OK if not bad else EX_NOPERM

def parse_protocol(text):
    """Parse one SCC/1.0 diagnostic interchange record."""
    lines=text.splitlines();
    if not lines or lines[0]!='SCC/1.0' or '.' not in lines[1:]: raise ValueError('invalid SCC/1.0 record')
    out={'version':'SCC/1.0'}
    for line in lines[1:]:
        if line=='.': break
        k,sep,v=line.partition(' ')
        if not sep or not k: raise ValueError('invalid field')
        out[k]=v
    return out
