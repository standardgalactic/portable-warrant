"""Fictional XENIX/386 compatibility personality for SCC.

This module changes presentation and administrative ergonomics only.  It does
not contain, derive from, or emulate Microsoft XENIX source code or kernel ABI.
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path
from .common import EX_OK, EX_NOPERM, EX_USAGE
from .retro import root_path, scan_store

PERSONALITY = "XENIX_SYSV_386"
BANNER = "SCC subsystem 0.4.1/x386"

def xenix_enabled() -> bool:
    """Return true when the alternate-history XENIX presentation is selected."""
    return os.environ.get("SCC_XENIX", "0").lower() in {"1", "yes", "true", "on"}

def cmd_xenix_init(a):
    """Initialize the relocatable SCC hierarchy without touching host /etc or /var."""
    root = root_path(a.root)
    dirs = [
        "etc/scc/domains.d", "etc/scc/properties.d", "etc/scc/projections.d", "etc/scc/trust.d",
        "etc/default", "var/lib/scc/proofs", "var/lib/scc/certificates", "var/lib/scc/registry",
        "var/log/scc", "var/spool/scc/audit", "var/spool/scc/outgoing",
    ]
    for d in dirs: (root/d).mkdir(parents=True, exist_ok=True)
    conf = root/"etc/scc/scc.conf"
    if not conf.exists() or a.force:
        conf.write_text(
            '# SCC 0.4.1 XENIX personality configuration\n'
            '[subsystem]\n'
            'environment = "XENIX_SYSV_386"\n'
            'oem_personality = "fictional Microsoft/SCO compatibility presentation"\n'
            'strict_file_locking = true\n'
            'audit_channel = "none"\n'
            '# audit_channel = "/dev/tty02"\n\n'
            '[limits]\nmax_certificate_chain_depth = 16\n'
            'enforce_segment_boundaries = true\nfail_closed_on_unknown_signal = true\n', encoding='utf-8')
    default = root/"etc/default/scc"
    if not default.exists() or a.force:
        default.write_text('SCC_XENIX=1\nSCC_PERSONALITY=XENIX_SYSV_386\n', encoding='utf-8')
    for f in (root/"var/log/scc/audit.jsonl", root/"var/log/scc/decisions.jsonl"):
        f.touch(exist_ok=True)
    if not a.quiet: print(f"sccinit: initialized {root}")
    return EX_OK

def cmd_xenix_stat(a):
    """Print terse period-style subsystem status."""
    root=root_path(a.root); s=scan_store(root)
    ledger=root/"var/log/scc/audit.jsonl"
    ledger_state="clean"
    if s['broken']: ledger_state="errors"
    print(BANNER)
    print(f"proofs      {s['proofs']:5d}")
    print(f"certs       {s['certificates']:5d}")
    print(f"orphans     {len(s['orphan_proofs']):5d}")
    print(f"broken      {len(s['broken']):5d}")
    print(f"ledger      {ledger_state}")
    print("warrant     idle")
    return EX_OK if not s['broken'] else EX_NOPERM

def cmd_xenix_adm(a):
    """Run XENIX-personality administrative consistency checks."""
    root=root_path(a.root); s=scan_store(root)
    if not a.quiet:
        print("checking proof store...")
        print("checking certificate parentage...")
        print("checking composition closure...")
        print("SCC FILE SYSTEM IS CLEAN" if not s['broken'] else "SCC FILE SYSTEM HAS ERRORS")
    return EX_OK if not s['broken'] else EX_NOPERM

def cmd_xenix_log(a):
    """Read the virtual SCC audit log in a simple terminal-oriented form."""
    p=root_path(a.root)/"var/log/scc/audit.jsonl"
    if not p.exists(): return EX_OK
    lines=p.read_text(encoding='utf-8').splitlines()
    for line in lines[-max(0,a.lines):]:
        if a.raw: print(line); continue
        try:
            d=json.loads(line); print(f"{d.get('timestamp','-')} {d.get('status',d.get('event','EVENT'))} {d.get('reason_code','-')}")
        except json.JSONDecodeError: print(line)
    return EX_OK

def scope_fault(reason: str) -> str:
    """Render an SCC logical-segment violation without implying a host SIGSEGV."""
    return f"SCOPE FAULT: {reason} -- null action"
