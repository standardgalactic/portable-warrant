"""Implementation of the Unix-style SCC command suite."""
from __future__ import annotations
import argparse, json, subprocess, sys, hmac, hashlib
from pathlib import Path
from typing import Any
from pydantic import ValidationError
from scc_runtime.models import ScopeCarryingCertificate
from neuroformal.runtime import compute_hash
from neuroformal.examples import defective_translate
from .common import *
from .retro import cmd_fsck, cmd_lint, cmd_dump, cmd_od, cmd_tail, cmd_replay
from .xenix import cmd_xenix_init, cmd_xenix_stat, cmd_xenix_adm, cmd_xenix_log

REASONS = {
 "UNVERIFIED_PROOF_OBLIGATION":"the certificate's static proof binding could not be authenticated",
 "DOMAIN_MISMATCH":"the current object is outside the admitted proof domain",
 "STALE_CERTIFICATE":"the certificate is outside its validity interval",
 "ASSUMPTION_FAILURE":"a required live environmental assumption lacks positive evidence",
 "UNAUTHORIZED_CONSUMER":"the requested consumer is outside the certificate scope",
 "DELEGATION_DEPTH_EXCEEDED":"the certificate has crossed its permitted delegation depth",
 "COMPOSITION_PROOF_REQUIRED":"a positive warrant cannot cross this transformation without composition evidence",
 "INVALID_COMPOSITION_PROOF":"the supplied composition artifact does not authenticate the requested handoff",
}

def _cert(path: str) -> ScopeCarryingCertificate:
    return ScopeCarryingCertificate.model_validate(read_json(path))

def cmd_hash(a):
    text=read_text(a.file)
    if a.json_input:
        text=canonical_json(json.loads(text))
    value=sha256_text(text)
    emit({"algorithm":"sha256","hash":value,"source":a.file}) if a.json else print(value)
    return EX_OK

def cmd_check(a):
    try: c=_cert(a.certificate)
    except (OSError,json.JSONDecodeError,ValidationError) as e:
        print(f"scc-check: {e}", file=sys.stderr); return EX_DATAERR
    emit({"valid":True,"certificate_id":c.certificate_id,"property_hash":c.property_hash,"projection_hash":c.projection_hash,"domain_hash":c.admitted_domain_hash})
    return EX_OK

def cmd_inspect(a):
    try: c=_cert(a.certificate)
    except Exception as e: print(f"scc-inspect: {e}",file=sys.stderr); return EX_DATAERR
    d=c.model_dump(mode="json")
    d["delegated"] = c.composition_scope.current_depth > 0
    d["remaining_delegation_depth"] = max(0,c.composition_scope.max_delegation_depth-c.composition_scope.current_depth)
    emit(d); return EX_OK

def cmd_explain(a):
    try: d=read_json(a.result)
    except Exception as e: print(f"scc-explain: {e}",file=sys.stderr); return EX_DATAERR
    reason=d.get("reason_code")
    out={"status":d.get("status"),"reason_code":reason,"explanation":REASONS.get(reason,"no additional explanation available"),"sink_invoked":d.get("sink_invoked",False)}
    emit(out); return EX_OK

def cmd_trace(a):
    try:
        c=_cert(a.certificate); state=read_json(a.state)
    except Exception as e: print(f"scc-trace: {e}",file=sys.stderr); return EX_DATAERR
    gates=[]
    gates.append({"gate":"certificate-shape","result":"PASS"})
    gates.append({"gate":"consumer-scope","result":"PASS" if a.consumer in c.composition_scope.permitted_consumers else "FAIL"})
    gates.append({"gate":"delegation-depth","result":"PASS" if c.composition_scope.current_depth <= c.composition_scope.max_delegation_depth else "FAIL"})
    gates.append({"gate":"domain","result":"UNRESOLVED","note":"domain semantics require a trusted registry; trace does not infer them from names"})
    gates.append({"gate":"environment","result":"UNRESOLVED","note":"live telemetry not supplied to the static trace"})
    gates.append({"gate":"composition","result":"REQUIRED" if c.composition_scope.current_depth>0 else "ROOT"})
    emit({"certificate_id":c.certificate_id,"consumer":a.consumer,"state":state,"gates":gates,"authorization":"NOT_DERIVED","note":"scc-trace is diagnostic and never grants a warrant"}); return EX_OK

def cmd_verify_chain(a):
    try: d=read_json(a.chain)
    except Exception as e: print(f"scc-verify-chain: {e}",file=sys.stderr); return EX_DATAERR
    required=("source_artifact_hash","translated_artifact_hash","formal_translated_artifact_hash","source_property_hash","bridge_source_property_hash","target_property_hash","bridge_target_property_hash")
    missing=[k for k in required if k not in d]
    if missing: emit({"verified":False,"reason":"MISSING_FIELDS","missing":missing}); return EX_DATAERR
    checks={
      "target_binding":d["translated_artifact_hash"]==d["formal_translated_artifact_hash"],
      "source_property_binding":d["source_property_hash"]==d["bridge_source_property_hash"],
      "target_property_binding":d["target_property_hash"]==d["bridge_target_property_hash"],
      "direction":d.get("direction") in ("EQUIVALENCE","TARGET_IMPLIES_SOURCE"),
    }
    ok=all(checks.values())
    emit({"verified":ok,"checks":checks,"note":"structural chain check only; registry-backed proof authentication remains a runtime obligation"})
    return EX_OK if ok else EX_NOPERM

def cmd_fiber(a):
    try: rows=read_json(a.cases)
    except Exception as e: print(f"scc-fiber: {e}",file=sys.stderr); return EX_DATAERR
    if not isinstance(rows,list): print("scc-fiber: cases must be a JSON array",file=sys.stderr); return EX_DATAERR
    fibers={}
    for i,row in enumerate(rows):
        key=canonical_json(row.get(a.transform_field)); prop=row.get(a.property_field)
        fibers.setdefault(key,[]).append({"index":i,"property":prop,"case":row})
    violations=[]
    for key,members in fibers.items():
        vals={canonical_json(m["property"]) for m in members}
        if len(vals)>1: violations.append({"transformed_value":json.loads(key),"members":members})
    emit({"preserves_property":not violations,"fiber_count":len(fibers),"violations":violations})
    return EX_OK if not violations else EX_NOPERM

def cmd_translate(a):
    source=read_text(a.source)
    if a.mode != "defective-demo": print("scc-translate: unsupported translator mode",file=sys.stderr); return EX_USAGE
    target=defective_translate(source)
    if a.output: Path(a.output).write_text(target,encoding="utf-8")
    record={"translator":"defective-demo","source_hash":compute_hash(source),"target_hash":compute_hash(target),"output":a.output}
    emit(record)
    if not a.output: print(target,file=sys.stderr)
    return EX_OK

def cmd_prove(a):
    target=read_text(a.target)
    # Demonstration wrapper: records the target identity; it does not impersonate a theorem prover.
    recognized=target.strip()=="(assert target_property_holds)"
    emit({"verifier":"demo-terminal-verifier","target_hash":compute_hash(target),"terminal_proof_verified":recognized,"warning":"demonstration verifier only; not a formal proof kernel"})
    return EX_OK if recognized else EX_NOPERM

def _decision_tag(decision: dict, key: bytes) -> str:
    payload={k:v for k,v in decision.items() if k != "auth_tag"}
    return "hmac-sha256:" + hmac.new(key, canonical_json(payload).encode(), hashlib.sha256).hexdigest()

def cmd_seal_decision(a):
    try:
        d=read_json(a.decision); key=Path(a.key).read_bytes()
    except Exception as e: print(f"scc-seal-decision: {e}",file=sys.stderr); return EX_DATAERR
    d["auth_tag"]=_decision_tag(d,key); emit(d); return EX_OK

def cmd_run(a):
    try:
        decision=read_json(a.decision); key=Path(a.key).read_bytes()
    except Exception as e: print(f"scc-run: {e}",file=sys.stderr); return EX_DATAERR
    supplied=decision.get("auth_tag")
    expected=_decision_tag(decision,key)
    if not isinstance(supplied,str) or not hmac.compare_digest(supplied,expected):
        print("scc-run: unauthenticated decision record; command not executed",file=sys.stderr); return EX_NOPERM
    if decision.get("status") != "PROCEED" or decision.get("sink_invoked") is not True:
        print("scc-run: warrant not derived; command not executed",file=sys.stderr); return EX_NOPERM
    if not a.command: print("scc-run: missing command",file=sys.stderr); return EX_USAGE
    p=subprocess.run(a.command, shell=False)
    return p.returncode

def parser():
    p=argparse.ArgumentParser(prog="scc",description="Scope-Carrying Certificate Unix tool suite")
    p.add_argument("--version",action="version",version="scc-reference 0.4.1 Research Unix / XENIX Personality")
    sp=p.add_subparsers(dest="sub",required=True)
    q=sp.add_parser("hash"); q.add_argument("file"); q.add_argument("--json-input",action="store_true"); q.add_argument("--json",action="store_true"); q.set_defaults(fn=cmd_hash)
    q=sp.add_parser("check"); q.add_argument("certificate"); q.set_defaults(fn=cmd_check)
    q=sp.add_parser("inspect"); q.add_argument("certificate"); q.set_defaults(fn=cmd_inspect)
    q=sp.add_parser("explain"); q.add_argument("result"); q.set_defaults(fn=cmd_explain)
    q=sp.add_parser("trace"); q.add_argument("certificate"); q.add_argument("state"); q.add_argument("--consumer",required=True); q.set_defaults(fn=cmd_trace)
    q=sp.add_parser("verify-chain"); q.add_argument("chain"); q.set_defaults(fn=cmd_verify_chain)
    q=sp.add_parser("fiber"); q.add_argument("cases"); q.add_argument("--transform-field",default="T"); q.add_argument("--property-field",default="Phi"); q.set_defaults(fn=cmd_fiber)
    q=sp.add_parser("translate"); q.add_argument("source"); q.add_argument("--mode",default="defective-demo"); q.add_argument("-o","--output"); q.set_defaults(fn=cmd_translate)
    q=sp.add_parser("prove"); q.add_argument("target"); q.set_defaults(fn=cmd_prove)
    q=sp.add_parser("seal-decision"); q.add_argument("decision"); q.add_argument("--key",required=True); q.set_defaults(fn=cmd_seal_decision)
    q=sp.add_parser("run"); q.add_argument("--decision",required=True); q.add_argument("--key",required=True); q.add_argument("command",nargs=argparse.REMAINDER); q.set_defaults(fn=cmd_run)
    q=sp.add_parser("fsck"); q.add_argument("--root"); q.add_argument("-q","--quiet",action="store_true"); q.set_defaults(fn=cmd_fsck)
    q=sp.add_parser("lint"); q.add_argument("--root"); q.add_argument("-q","--quiet",action="store_true"); q.set_defaults(fn=cmd_lint)
    q=sp.add_parser("dump"); q.add_argument("file"); q.set_defaults(fn=cmd_dump)
    q=sp.add_parser("od"); q.add_argument("file"); q.set_defaults(fn=cmd_od)
    q=sp.add_parser("tail"); q.add_argument("file"); q.add_argument("-n","--lines",type=int,default=10); q.add_argument("-f","--follow",action="store_true"); q.set_defaults(fn=cmd_tail)
    q=sp.add_parser("replay"); q.add_argument("file"); q.set_defaults(fn=cmd_replay)
    q=sp.add_parser("xenix-init"); q.add_argument("--root"); q.add_argument("-q","--quiet",action="store_true"); q.add_argument("-f","--force",action="store_true"); q.set_defaults(fn=cmd_xenix_init)
    q=sp.add_parser("xenix-stat"); q.add_argument("--root"); q.set_defaults(fn=cmd_xenix_stat)
    q=sp.add_parser("xenix-adm"); q.add_argument("--root"); q.add_argument("-q","--quiet",action="store_true"); q.set_defaults(fn=cmd_xenix_adm)
    q=sp.add_parser("xenix-log"); q.add_argument("--root"); q.add_argument("-n","--lines",type=int,default=20); q.add_argument("--raw",action="store_true"); q.set_defaults(fn=cmd_xenix_log)
    return p

def main(argv=None):
    a=parser().parse_args(argv)
    try: return a.fn(a)
    except BrokenPipeError: return EX_OK
    except FileNotFoundError as e: print(f"scc: {e}",file=sys.stderr); return EX_NOINPUT
    except Exception as e: print(f"scc: internal error: {e}",file=sys.stderr); return EX_SOFTWARE

# Console-script wrappers.
def _sub(name):
    return main([name,*sys.argv[1:]])
def hash_main(): return _sub("hash")
def check_main(): return _sub("check")
def inspect_main(): return _sub("inspect")
def explain_main(): return _sub("explain")
def trace_main(): return _sub("trace")
def verify_chain_main(): return _sub("verify-chain")
def fiber_main(): return _sub("fiber")
def translate_main(): return _sub("translate")
def prove_main(): return _sub("prove")
def seal_decision_main(): return _sub("seal-decision")
def run_main(): return _sub("run")

def fsck_main(): return _sub("fsck")
def lint_main(): return _sub("lint")
def dump_main(): return _sub("dump")
def od_main(): return _sub("od")
def tail_main(): return _sub("tail")
def replay_main(): return _sub("replay")

def xenix_init_main(): return _sub("xenix-init")
def xenix_stat_main(): return _sub("xenix-stat")
def xenix_adm_main(): return _sub("xenix-adm")
def xenix_log_main(): return _sub("xenix-log")
