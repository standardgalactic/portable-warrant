"""Unix-style command interfaces for the SCC reference implementation."""

__version__ = "0.2.0"
