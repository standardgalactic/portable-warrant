"""Shared I/O and exit-status helpers for SCC command-line tools."""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
from typing import Any

EX_OK=0
EX_USAGE=64
EX_DATAERR=65
EX_NOINPUT=66
EX_UNAVAILABLE=69
EX_SOFTWARE=70
EX_NOPERM=77


def read_text(path: str) -> str:
    """Read UTF-8 text from PATH, or standard input when PATH is '-'."""
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8")


def read_json(path: str) -> Any:
    """Parse a JSON document from PATH, or standard input when PATH is '-'."""
    return json.loads(read_text(path))


def canonical_json(value: Any) -> str:
    """Return deterministic compact JSON suitable for hashing and audit records."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text: str) -> str:
    """Return an SCC-style SHA-256 identifier for UTF-8 TEXT."""
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def emit(value: Any, *, pretty: bool=True) -> None:
    """Write VALUE as JSON to standard output."""
    print(json.dumps(value, indent=2 if pretty else None, sort_keys=True, default=str))
