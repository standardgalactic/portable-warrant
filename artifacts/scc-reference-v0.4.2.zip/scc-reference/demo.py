"""demo.py: documented component of the SCC warrant-preservation reference implementation.

See docs/api.md and the man/ hierarchy for Unix-style interface contracts, failure
semantics, examples, and cross-references.
"""

from datetime import datetime, timedelta

from scc_runtime import (
    CompositionScope,
    History,
    SCCRuntimeEngine,
    ScopeCarryingCertificate,
    TrustedProofRegistry,
    VerifiedCompositionArtifact,
    VerifiedProofArtifact,
    legacy_boolean_runtime,
)

PROPERTY = "sha256:property:destination-safety:v1"
PROJECTION_SAFE = "sha256:projection:identity-safe:v1"
PROJECTION_BAD = "sha256:projection:erase-origin:v1"
DOMAIN_SAFE = "sha256:domain:public-origin-external-dest:v1"
TRANSFORM_A_B = "sha256:transform:A-to-B:v1"
VERIFIER = "scc-verifier/1.0"


def make_registry() -> TrustedProofRegistry:
    """Implement the `make_registry` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    registry = TrustedProofRegistry()
    registry.register_domain(
        DOMAIN_SAFE,
        lambda h: h.origin == "public" and h.destination == "external",
    )
    registry.register_proof(
        VerifiedProofArtifact(
            proof_hash="sha256:proof:valid-factorization:v1",
            property_hash=PROPERTY,
            projection_hash=PROJECTION_SAFE,
            domain_hash=DOMAIN_SAFE,
            verifier_version=VERIFIER,
            factorization_verified=True,
        )
    )
    return registry


def make_cert(now: datetime, *, projection_hash: str = PROJECTION_SAFE, proof_hash: str = "sha256:proof:valid-factorization:v1", depth: int = 0, consumers=None) -> ScopeCarryingCertificate:
    """Implement the `make_cert` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    return ScopeCarryingCertificate(
        certificate_id="cert-A-001",
        property_hash=PROPERTY,
        projection_hash=projection_hash,
        proof_hash=proof_hash,
        admitted_domain_hash=DOMAIN_SAFE,
        verifier_version=VERIFIER,
        environmental_assumptions=["secure_channel"],
        validity_interval=(now - timedelta(hours=1), now + timedelta(hours=1)),
        composition_scope=CompositionScope(
            permitted_consumers=consumers or ["Sink"],
            max_delegation_depth=1,
            current_depth=depth,
            allow_delegation=True,
        ),
        disposition="PROCEED",
        boundary_observations={"origin": "public", "destination": "external"},
    )


def show(label, result):
    """Implement the `show` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    print(f"{label:<29} Status={result.status:<11} Reason={str(result.reason_code):<31} Sink={result.sink_invoked}")


def run_test_matrix() -> None:
    """Implement the `run_test_matrix` operation documented in the API and manual pages.

    See docs/api.md and the corresponding section-3 manual page for arguments, return values, side effects, failure modes, and security semantics.
    """
    now = datetime(2026, 9, 25, 12, 0, 0)
    registry = make_registry()
    engine = SCCRuntimeEngine(now, registry)
    safe = History(origin="public", destination="external")
    unsafe = History(origin="restricted", destination="external")

    print("=== LEGACY COUNTEREXAMPLE ===")
    legacy = legacy_boolean_runtime(unsafe)
    print(f"Legacy sink invoked={legacy.sink_invoked}; invariant violated={legacy.global_invariant_violated}\n")

    print("=== SCC REFERENCE IMPLEMENTATION: 7-ROW TEST MATRIX ===")

    bad = make_cert(now, projection_hash=PROJECTION_BAD, proof_hash="sha256:proof:forged")
    show("1. Fiber counterexample", engine.evaluate_warrant(bad, unsafe, "Sink", environmental_state={"secure_channel": True}))

    valid = make_cert(now)
    show("2. Valid root action", engine.evaluate_warrant(valid, safe, "Sink", environmental_state={"secure_channel": True}))

    show("3. Domain escape", engine.evaluate_warrant(valid, unsafe, "Sink", environmental_state={"secure_channel": True}))

    delegated = make_cert(now, depth=1, consumers=["Agent_B"])
    show("4. Composition failure", engine.evaluate_warrant(delegated, safe, "Agent_B", environmental_state={"secure_channel": True}))

    show("5. Environment drift", engine.evaluate_warrant(valid, safe, "Sink", environmental_state={"secure_channel": False}))

    stale = valid.model_copy(update={"validity_interval": (now - timedelta(hours=5), now - timedelta(hours=2))})
    show("6. Stale certificate", engine.evaluate_warrant(stale, safe, "Sink", environmental_state={"secure_channel": True}))

    registry.register_composition(
        VerifiedCompositionArtifact(
            proof_hash="sha256:composition:A-B:v1",
            parent_certificate_id=delegated.certificate_id,
            consumer_agent_id="Agent_B",
            transformation_hash=TRANSFORM_A_B,
            property_hash=PROPERTY,
            domain_hash=DOMAIN_SAFE,
            verifier_version=VERIFIER,
            composition_verified=True,
        )
    )
    show(
        "7. Fully certified chain",
        engine.evaluate_warrant(
            delegated,
            safe,
            "Agent_B",
            composition_proof_hash="sha256:composition:A-B:v1",
            transformation_hash=TRANSFORM_A_B,
            environmental_state={"secure_channel": True},
        ),
    )


if __name__ == "__main__":
    run_test_matrix()
